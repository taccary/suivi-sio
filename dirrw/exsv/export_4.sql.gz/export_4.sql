CREATE TABLE `port_activite` (
  `id` smallint(6) NOT NULL,
  `idDomaine` smallint(6) NOT NULL,
  `nomenclature` char(7) NOT NULL,
  `lngutile` smallint(6) NOT NULL,
  `libelle` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
insert into port_activite values('1','1','A1.1.1','54','Analyse du cahier des charges d\'un service à produire');
insert into port_activite values('2','1','A1.1.2','47','Étude de l\'impact de l\'intégration d\'un service sur le système informatique');
insert into port_activite values('3','1','A1.1.3','47','Étude des exigences liées à la qualité attendue d\'un service');
insert into port_activite values('4','2','A1.2.1','49','Élaboration et présentation d\'un dossier de choix de solution technique');
insert into port_activite values('5','2','A1.2.2','54','Rédaction des spécifications techniques de la solution retenue (adaptation d\'une solution existante ou réalisation d\'une nouvelle solution)');
insert into port_activite values('6','2','A1.2.3','57','Évaluation des risques liés à l\'utilisation d\'un service');
insert into port_activite values('7','2','A1.2.4','51','Détermination des tests nécessaires à la validation d\'un service');
insert into port_activite values('8','2','A1.2.5','37','Définition des niveaux d\'habilitation associés à un service');
insert into port_activite values('9','3','A1.3.1','49','Test d\'intégration et d\'acceptation d\'un service');
insert into port_activite values('10','3','A1.3.2','51','Définition des éléments nécessaires à la continuité d\'un service');
insert into port_activite values('11','3','A1.3.3','56','Accompagnement de la mise en place d\'un nouveau service');
insert into port_activite values('12','3','A1.3.4','25','Déploiement d\'un service');
insert into port_activite values('13','4','A1.4.1','25','Participation à un projet');
insert into port_activite values('14','4','A1.4.2','47','Évaluation des indicateurs de suivi d\'un projet et justification des écarts');
insert into port_activite values('15','4','A1.4.3','22','Gestion des ressources');
insert into port_activite values('16','5','A2.1.1','53','Accompagnement des utilisateurs dans la prise en main d\'un service');
insert into port_activite values('17','5','A2.1.2','50','Évaluation et maintien de la qualité d\'un service');
insert into port_activite values('18','6','A2.2.1','32','Suivi et résolution d\'incidents');
insert into port_activite values('19','6','A2.2.2','45','Suivi et réponse à des demandes d\'assistance');
insert into port_activite values('20','6','A2.2.3','37','Réponse à une interruption de service');
insert into port_activite values('21','7','A2.3.1','58','Identification, qualification et évaluation d\'un problème');
insert into port_activite values('22','7','A2.3.2','41','Proposition d\'amélioration d\'un service');
insert into port_activite values('23','8','A3.1.1','45','Proposition d\'une solution d\'infrastructure');
insert into port_activite values('24','8','A3.1.2','58','Maquettage et prototypage d\'une solution d\'infrastructure');
insert into port_activite values('25','8','A3.1.3','48','Prise en compte du niveau de sécurité nécessaire à une infrastructure');
insert into port_activite values('26','9','A3.2.1','57','Installation et configuration d\'éléments d\'infrastructure');
insert into port_activite values('27','9','A3.2.2','49','Remplacement ou mise à jour d\'éléments défectueux ou obsolètes');
insert into port_activite values('28','9','A3.2.3','41','Mise à jour de la documentation technique d\'une solution d\'infrastructure');
insert into port_activite values('29','10','A3.3.1','50','Administration sur site ou à distance des éléments d\'un réseau, de serveurs, de services et d\'équipements terminaux');
insert into port_activite values('30','10','A3.3.2','59','Planification des sauvegardes et gestion des restaurations');
insert into port_activite values('31','10','A3.3.3','42','Gestion des identités et des habilitations');
insert into port_activite values('32','10','A3.3.4','43','Automatisation des tâches d\'administration');
insert into port_activite values('33','10','A3.3.5','51','Gestion des indicateurs et des fichiers d\'activité');
insert into port_activite values('34','11','A4.1.1','39','Proposition d\'une solution applicative');
insert into port_activite values('35','11','A4.1.2','51','Conception ou adaptation de l\'interface utilisateur d\'une solution applicative');
insert into port_activite values('36','11','A4.1.3','47','Conception ou adaptation d\'une base de données');
insert into port_activite values('37','11','A4.1.4','59','Définition des caractéristiques d\'une solution applicative');
insert into port_activite values('38','11','A4.1.5','35','Prototypage de composants logiciels');
insert into port_activite values('39','11','A4.1.6','53','Gestion d\'environnements de développement et de test');
insert into port_activite values('40','11','A4.1.7','54','Développement, utilisation ou adaptation de composants logiciels');
insert into port_activite values('41','11','A4.1.8','49','Réalisation des tests nécessaires à la validation d\'éléments adaptés ou développés');
insert into port_activite values('42','11','A4.1.9','40','Rédaction d\'une documentation technique');
insert into port_activite values('43','11','A4.1.10','45','Rédaction d\'une documentation d\'utilisation');
insert into port_activite values('44','12','A4.2.1','44','Analyse et correction d\'un dysfonctionnement, d\'un problème de qualité de service ou de sécurité');
insert into port_activite values('45','12','A4.2.2','52','Adaptation d\'une solution applicative aux évolutions de ses composants');
insert into port_activite values('46','12','A4.2.3','57','Réalisation des tests nécessaires à la mise en production d\'éléments mis à jour');
insert into port_activite values('47','12','A4.2.4','42','Mise à jour d\'une documentation technique');
insert into port_activite values('48','13','A5.1.1','45','Mise en place d\'une gestion de configuration');
insert into port_activite values('49','13','A5.1.2','44','Recueil d\'informations sur une configuration et ses éléments');
insert into port_activite values('50','13','A5.1.3','45','Suivi d\'une configuration et de ses éléments');
insert into port_activite values('51','13','A5.1.4','43','Étude de propositions de contrat de service (client, fournisseur)');
insert into port_activite values('52','13','A5.1.5','40','Évaluation d\'un élément de configuration ou d\'une configuration');
insert into port_activite values('53','13','A5.1.6','44','Évaluation d\'un investissement informatique');
insert into port_activite values('54','14','A5.2.1','50','Exploitation des référentiels, normes et standards adoptés par le prestataire informatique');
insert into port_activite values('55','14','A5.2.2','20','Veille technologique');
insert into port_activite values('56','14','A5.2.3','37','Repérage des compléments de formation ou d\'auto-formation utiles à l\'acquisition de nouvelles compétences');
insert into port_activite values('57','14','A5.2.4','51','Étude d‘une technologie, d\'un composant, d\'un outil ou d\'une méthode');
CREATE TABLE `port_activitecitee` (
  `idActivite` smallint(6) NOT NULL,
  `refSituation` int(11) NOT NULL,
  `commentaire` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`idActivite`,`refSituation`),
  KEY `iaccisitu` (`refSituation`),
  CONSTRAINT `port_activitecitee_ibfk_1` FOREIGN KEY (`refSituation`) REFERENCES `port_situation` (`ref`),
  CONSTRAINT `port_activitecitee_ibfk_2` FOREIGN KEY (`idActivite`) REFERENCES `port_activite` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
insert into port_activitecitee values('1','14','Le service infrastructure et moi avons établi un cahier des charges des éléments à superviser (routeur, switch...), machines (serveur...), éléments physiques (disque dur, carte réseau...) et services (http, etc.)');
insert into port_activitecitee values('1','80','Lecture du cahier des charges de l\\\'application, et listage des tâches à effectuer.');
insert into port_activitecitee values('1','81','Analyse du cahier des charges et listage des tâches.');
insert into port_activitecitee values('1','176','(P) Réunions, avec le responsable de l\\\'entreprise, qui ont permis une étude approfondie des fonctionnalités attendues (fichiers Excel en support fournis). ');
insert into port_activitecitee values('1','363','(P) Analyse du cahier des charges et rédaction d\\\'un document résumant les différentes tâches à effectuer par chaque membre de l\\\'équipe.');
insert into port_activitecitee values('1','406','(P) Analyse du cahier des charges et rédaction d\\\'un résumé simplifié du cahier des charges.');
insert into port_activitecitee values('1','543','Identification des fonctionnalités attendues présentées dans le cahier des charges (seulement celui destiné aux éditeurs - confidentialité)');
insert into port_activitecitee values('1','544','Identification des fonctionnalités attendues présentées dans le cahier des charges (réalisé par moi-même)');
insert into port_activitecitee values('1','605','Analyse du cahier des charges et adaptation du développement');
insert into port_activitecitee values('1','607','Analyse du cahier des charges');
insert into port_activitecitee values('1','608','Analyse du cahier des charges');
insert into port_activitecitee values('1','609','Analyse du cahier des charges et adaptation du développement');
insert into port_activitecitee values('1','1327','fezkopgejhtpojt');
insert into port_activitecitee values('2','80','Analyse des conséquences de l\\\'intégration d\\\'une nouvelle application au système de données.');
insert into port_activitecitee values('2','81','Etudes des conséquences de l’intégration d\\\'une nouvelle application aux système.');
insert into port_activitecitee values('2','443','Étude d\\\'un logiciel implanté dans l\\\'entreprise');
insert into port_activitecitee values('2','542','Je me suis renseigné sur le fonctionnement de l\\\'ancien site d\\\'Ukronium1828, hébergeur etc... avant de mettre celui que j\\\'ai développé en ligne');
insert into port_activitecitee values('2','607','Analyse des différentes parties du projet');
insert into port_activitecitee values('2','608','Analyse des différentes parties du projet');
insert into port_activitecitee values('2','1327','hqrwjytèol');
insert into port_activitecitee values('3','14','Etude de moyens de remontées automatiques (NRPE, WMI, SNMP, NSClient++ ...) vis-à-vis du cahier des charges');
insert into port_activitecitee values('3','122','Etudes des propositions du client, et, proposer une solutions alternative à ce qui n\\\'est pas faisable.');
insert into port_activitecitee values('3','321','(P) Ecriture des différentes exigences attendues pour la modification d\\\'un thème Wordpress (ex : rendre le site administrable par l\\\'utilisateur) - Tâche n°14 -');
insert into port_activitecitee values('3','542','J\\\'ai réfléchi sur le besoin de sécurité des comptes utilisateurs notamment avec le paiement e-commerce, SSL ou non, paiement direct ou non');
insert into port_activitecitee values('4','429','Proposition de plusieurs interfaces.');
insert into port_activitecitee values('4','463','Benchmark sur différentes technologies web et mobiles et différents langages afin d\\\'orienter les choix de l\\\'entreprise pour la création d\\\'un site web et d\\\'une application mobile.');
insert into port_activitecitee values('4','1327','rjygkyupimôimiuyytk');
insert into port_activitecitee values('5','14','Dans la procédure d\\\'installation de FAN, j\\\'indique les caractéristiques techniques minimum nécessaires (RAM, espace disque, etc.), les recommandations en cas de virtualisation. En outre, j\\\'expose les plugins nécessaires à la supervision de services.');
insert into port_activitecitee values('5','81','Production d\\\'une documentation technique.');
insert into port_activitecitee values('5','140','Rédaction d\\\'un dossier de spécifications techniques.');
insert into port_activitecitee values('5','141','Rédaction d\\\'un dossier de spécifications techniques.');
insert into port_activitecitee values('5','176','(P) Documentation sur les spécifications techniques.\r\nRépertoire des différentes fonctionnalités attendues.');
insert into port_activitecitee values('5','429','Rédaction des différents éléments techniques mis à jour.');
insert into port_activitecitee values('5','544','Rédaction du cahier des charges du nouveau composant logiciel');
insert into port_activitecitee values('5','607','Rédaction de documentations');
insert into port_activitecitee values('5','608','Rédaction de documentations');
insert into port_activitecitee values('6','14','J\\\'ai remarqué que les données qui transitaient par le protocole SNMP version 1 et 2 n\\\'étaient pas cryptées, qu\\\'il fallait respecter les recommandations de l\\\'espace disque du serveur et limiter l\\\'utilisation du SNMP du fait que ce protocole communique');
insert into port_activitecitee values('6','122','Etudes des risques. Installation de sécurité en cas de mauvaise manipulation par l\\\'utilisateur.');
insert into port_activitecitee values('6','443','Évaluation des risques liés à son utilisation');
insert into port_activitecitee values('7','140','Préparation de jeux d\\\'essai pour tester l\\\'application.');
insert into port_activitecitee values('7','141','Préparation de jeux d\\\'essai pour tester l\\\'application.');
insert into port_activitecitee values('7','607','Réalisation de tests');
insert into port_activitecitee values('7','608','Réalisation de tests');
insert into port_activitecitee values('7','1327','');
insert into port_activitecitee values('8','122','Définitions des informations visible selon les rôles, et attributions de ces rôles aux utilisateurs.');
insert into port_activitecitee values('9','14','Mise en place de Centreon/Nagios par FAN sur un serveur virtuel et accès à la plateforme de supervision via un navigateur à l\\\'adresse http://IP-du-serveur/');
insert into port_activitecitee values('9','140','Test, et rédaction de rapport de test des applications.');
insert into port_activitecitee values('9','141','Test, et rédaction de rapport de test des applications.');
insert into port_activitecitee values('9','429','Tests du nouveau annuaire via le backoffice du site (prévisualisation). ');
insert into port_activitecitee values('9','543','Test du service sur un poste client distant exploitant le web service ');
insert into port_activitecitee values('9','544','Mise en place de l\\\'environnement de test');
insert into port_activitecitee values('9','607','Tests tout au long du développement');
insert into port_activitecitee values('9','608','Tests tout au long du développement');
insert into port_activitecitee values('11','14','En fin de stage, j\\\'ai réalisé une réunion sur tout ce qui a été mis en place et j\\\'ai informé et formé l\\\'administrateur système et technicien &amp; technicien support sur l\\\'utilisation et le fonctionnement de Nagios/Centreon.');
insert into port_activitecitee values('11','185','Formation des utilisateurs : explication orale au responsable, concernant l\\\'utilisation de l\\\'application et réalisation d\\\'une documentation utilisateur laissée à disposition des utilisateurs.');
insert into port_activitecitee values('11','429','Explication de l\\\'utilisation de l\\\'annuaire aux membres de l\\\'entreprise.');
insert into port_activitecitee values('11','446','Accompagnement des membres de l\\\'entreprise de la mise en place du logiciel');
insert into port_activitecitee values('11','480','Vers la fin du stage, rédaction d\\\'un document pour expliquer comment mettre en place localement le site développé et expliquer son fonctionnement');
insert into port_activitecitee values('11','542','Mise en ligne du site sur 1&amp;1 et formation des employés d\\\'Ukronium1828 à l\\\'utilisation du back-office');
insert into port_activitecitee values('12','122','Mise en production de l\\\'application Web.');
insert into port_activitecitee values('12','140','Déploiement de l\\\'application Web sur le serveur.');
insert into port_activitecitee values('12','141','Déploiement de l\\\'application Web sur le serveur.');
insert into port_activitecitee values('12','185','Mise en production de l\\\'application : déploiement de l\\\'application sur l\\\'ordinateur du responsable.');
insert into port_activitecitee values('12','429','Mise en ligne du contenu modifié.');
insert into port_activitecitee values('12','446','Mise en place du logiciel sur le NAS');
insert into port_activitecitee values('12','542','Déploiement de l\\\'application web Ukronium1828 sur 1&amp;1');
insert into port_activitecitee values('12','543','Mise en place du connecteur sur l\\\'application (mise en production réalisée par un collègue) via Eclipse');
insert into port_activitecitee values('12','544','Déploiement du service sur le portail applicatif via Eclipse');
insert into port_activitecitee values('13','14','Au sein du service infrastructure, nous avons établi un planning sur les objectifs attendus. De plus, je générais un rapport d\\\'activités journalier mis à disposition des employés.');
insert into port_activitecitee values('13','16','Participation au Développement de l\\\'application web : Environnement numérique de travail d\\\'exalta.');
insert into port_activitecitee values('13','80','Travail sur l\\\'application et production de document permettant de rendre compte du travail effectué.');
insert into port_activitecitee values('13','81','Participation au projet et production d\\\'une documentation.');
insert into port_activitecitee values('13','122','Participation au projet du stage. Développement de l\\\'application Web. Rendre compte au maître de stage.');
insert into port_activitecitee values('13','177','(P) Mise au point d\\\'un planning pour la gestion du temps et démonstration de l\\\'application au fur et à mesure de l\\\'avancement.');
insert into port_activitecitee values('13','321','(P) Utilisation d\\\'une application permettant de gérer les tâches et rendre compte de son travail et constater l\\\'avancement.');
insert into port_activitecitee values('13','363','Gestion du projet en tant que chef de projet.\r\nCompte-rendu oral de l\\\'avancement du projet de la part de chaque membre de l\\\'équipe.');
insert into port_activitecitee values('13','406','');
insert into port_activitecitee values('13','429','Participation au projet de rénovation d\\\'une partie du site.');
insert into port_activitecitee values('13','480','Dans un projet de création d\\\'entreprise, j\\\'ai été responsable de la partie développement.\r\nRapport quotidien de l\\\'avancement par mail.');
insert into port_activitecitee values('13','542','Projet de création du site web d\\\'Ukronium1828. Rapport continu de l\\\'avancement, travaillant dans le même bureau que le patron, + rapport hebdomadaire écrit');
insert into port_activitecitee values('13','543','Compte rendu des activités au chef de projet quotidiennement');
insert into port_activitecitee values('13','544','Compte rendu d\\\'activités au chef de projet');
insert into port_activitecitee values('13','605','Participation à un projet de dev C#. Compte rendu via un Gant');
insert into port_activitecitee values('13','607','Exploitation d\\\'un diagramme de Gantt');
insert into port_activitecitee values('13','608','Exploitation d\\\'un diagramme de Gantt');
insert into port_activitecitee values('13','609','Participation à un projet de dev PHP. Compte rendu via un Gant');
insert into port_activitecitee values('14','14','J\\\'ai adapté mes investigations en fonction du planning et des difficultés/écarts rencontrés durant le projet.');
insert into port_activitecitee values('14','80','Suivis du travail des différents membres de l\\\'équipe, analyse du retard ou de l\\\'avance prise sur le planning établit, évaluation des performances de l\\\'équipe.');
insert into port_activitecitee values('14','446','Utilisation du logiciel (gestion de projets)');
insert into port_activitecitee values('14','607','Conception d\\\'un diagramme de Gantt');
insert into port_activitecitee values('14','608','Conception d\\\'un diagramme de Gantt');
insert into port_activitecitee values('15','14','J\\\'ai su géré la supervision d\\\'éléments de réseau en fonction des ressources mises à disposition : IP de tel serveur, les identifiants, l\\\'accès à distance, l\\\'accès à internet, etc.');
insert into port_activitecitee values('15','122','Estimations du temps de travail en fonction du nombres de personnes travaillant sur le projet. Affectation des tâches.');
insert into port_activitecitee values('15','446','Gestion des ressources avec ce logiciel');
insert into port_activitecitee values('15','542','Analyse des moyens financiers de l\\\'entreprise et rétractation à l\\\'utilisation seulement de services gratuits');
insert into port_activitecitee values('16','16','Démonstration et explication du fonctionnement de l\\\'application aux employés.');
insert into port_activitecitee values('16','122','Formation du maître de stage à CodeIgniter.');
insert into port_activitecitee values('16','185','Présentation de l\\\'application répondant correctement aux besoins des utilisateurs.\r\nAide à l\\\'utilisation de l\\\'application lorsqu\\\'une partie de celle-ci était déployée.');
insert into port_activitecitee values('16','429','Consultation de l\\\'équipe pour changements éventuels, prise en compte de la satisfaction');
insert into port_activitecitee values('16','446','Accompagnement des membres de l\\\'entreprise sur l\\\'utilisation du logiciel');
insert into port_activitecitee values('16','542','Formation des employés Ukronium1828 à l\\\'utilisation du back-office et à WordPress');
insert into port_activitecitee values('17','14','j\\\'ai supervisé différents services tels que le http, FTP, SMTP... \r\nJ\\\'ai analysé des graphes portant sur la disponibilité de services supervisés.');
insert into port_activitecitee values('17','542','Analyse de la vitesse (https://developers.google.com/speed/pagespeed/insights/), sécurité, responsive du site');
insert into port_activitecitee values('18','112','j\\\'ai résolu des problèmes d\\\'ordre matériel, logiciel, etc.\r\nj\\\'ai suivi des documentations internes à l\\\'entreprise, assisté des utilisateurs, utilisé une plateforme de gestion des tickets d\\\'incidents (GLPI) pour le suivi et la résolution...');
insert into port_activitecitee values('18','166','j\\\'ai résolu des problèmes d\\\'ordre matériel, logiciel, etc.\r\nj\\\'ai suivi des documentations internes à l\\\'entreprise, utilisé une plateforme de gestion des tickets d\\\'incidents (GLPI) pour le suivi et la résolution...');
insert into port_activitecitee values('18','442','Rédaction d\\\'un rapport de demande d\\\'assistance');
insert into port_activitecitee values('19','112','j\\\'ai été amené à résoudre des problèmes en tous genres.\r\nj\\\'ai suivi des documentations internes à l\\\'entreprise, assisté des utilisateurs, utilisé une plateforme de gestion des tickets d\\\'incidents (GLPI) pour le suivi et la résolution...');
insert into port_activitecitee values('19','442','Identification du problème, recherche de solutions');
insert into port_activitecitee values('20','442','Adresse mail indisponible, risque de perte de courriers importants');
insert into port_activitecitee values('21','122','Prise en charges de plusieurs bugs. Définition du degré d\\\'urgence. Résolution des bugs.');
insert into port_activitecitee values('21','442','Rédaction d\\\'un rapport d\\\'incidents (problèmes, procédure, solutions)');
insert into port_activitecitee values('21','542','Résolutions de bugs tout au long du développement (ex : bug ajax avec woocommerce, bug du double attribut &lt;title&gt;, etc ...)');
insert into port_activitecitee values('22','11','Proposition de remplacement de la base de données Access par un application web, accessible à tous les employés de façon intuitive.');
insert into port_activitecitee values('22','16','Proposition de remplacement d\\\'un script VBA par une application PHP complète et intuitive.');
insert into port_activitecitee values('22','122','Reflexion autour du projet d\\\'amélioration de l\\\'ENT.');
insert into port_activitecitee values('22','176','Proposition d\\\'améliorations afin d\\\'optimiser certaines fonctionnalités attendues (ex : TVA par défaut, pour un fournisseur, supprimée car elle peut être différente selon les produits -&gt; montant TTC pourrait être faux)');
insert into port_activitecitee values('22','443','Proposition d\\\'améliorations du service (interface etc)');
insert into port_activitecitee values('22','444','Intégration du script sur le site.');
insert into port_activitecitee values('22','542','Proposition d\\\'amélioration constante de services (cache, etc)');
insert into port_activitecitee values('24','122','Création de maquettes d\\\'interfaces.');
insert into port_activitecitee values('26','16','Installation et Configuration d\\\'un serveur Web : Apache, Mysql, PHP.');
insert into port_activitecitee values('26','140','Configuration d\\\'un serveur Microsoft Windows Serveur 2012.\r\nInstallation et configuration d\\\'un serveur Apache.\r\nInstallation et configuration d\\\'un serveur Microsoft SQL 2012.');
insert into port_activitecitee values('26','141','Configuration d\\\'un serveur Microsoft Windows Serveur 2012.\r\nInstallation et configuration d\\\'un serveur Apache.\r\nInstallation et configuration d\\\'un serveur Microsoft SQL 2012.');
insert into port_activitecitee values('27','11','Passage d\'une base Access non normalisé et non optimisé, à une base de données MySQL normalisé et optimisé.');
insert into port_activitecitee values('27','16','Remplacement d\\\'une base de données Access et de son script VBA par une base de données MySQL et son application PHP.');
insert into port_activitecitee values('28','542','Complétion de la documentation liée au service développé');
insert into port_activitecitee values('29','14','j\\\'ai installé le protocole SNMP, à distance, sur des OS Microsoft Windows server 2003 et 2008. J\\\'ai utilisé les logiciels Putty et WinSCP pour la manipulation de fichiers/dossiers (notamment pour l\\\'ajout de plugins Nagios sur le serveur de supervision)');
insert into port_activitecitee values('29','112','Au cours du stage, j\\\'ai administré des ordinateurs appartenant à des utilisateurs distants suite à des incidents déclarés auparavant.');
insert into port_activitecitee values('29','166','Au cours du stage, j\\\'ai administré des serveurs à distance suite à des incidents déclarés auparavant.');
insert into port_activitecitee values('30','122','Automatisation de la sauvegarde de la base de données.');
insert into port_activitecitee values('31','112','Durant le stage, il m\\\'est arrivé de gérer l\\\'arborescence des contrôleurs de domaine de l\\\'entreprise , notamment pour gestion de compte (création, suppression, modification)et la gestion des droits.');
insert into port_activitecitee values('32','542','Auto-cochage d\\\'options selon les besoins du client pour simplifier le back office');
insert into port_activitecitee values('33','14','j\\\'ai adapté des graphes sur Centreon en fonction d\\\'une certaine période (date) pour obtenir un indicateur d\\\'activité d\\\'éléments de réseau.');
insert into port_activitecitee values('33','542','Confidentialité des données. Rédaction des mentions légales après étude sur Internet');
insert into port_activitecitee values('34','16','Proposition du Framework Symfony 2.');
insert into port_activitecitee values('34','122','Proposition des améliorations à effectuer sur la nouvelle version de l\\\'application.');
insert into port_activitecitee values('34','446','Proposition d\\\'un logiciel de gestion de projet');
insert into port_activitecitee values('34','463','Le dossier rédigé a servi de base à une restitution orale quotidienne');
insert into port_activitecitee values('34','542','Conception de services et estimation des délais');
insert into port_activitecitee values('34','544','Estimation du délai de réalisation de la mission et conception de la solution');
insert into port_activitecitee values('35','16','Conception de l\\\'interface utilisateur de l\\\'application Web, de la façons la plus intuitive possible.');
insert into port_activitecitee values('35','80','Définition des spécifications de l\\\'application, création d\\\'une maquette et validation par l\\\'équipe du choix de la technologie employée.');
insert into port_activitecitee values('35','122','Définition des besoin pour les nouvelles interfaces. Validation par le maître de stage. Conception de ces interfaces.');
insert into port_activitecitee values('35','140','Création de maquettes de l\\\'interface de l\\\'application.\r\nConception de l\\\'interface de l\\\'application.');
insert into port_activitecitee values('35','141','Création de maquettes de l\\\'interface de l\\\'application.\r\nConception de l\\\'interface de l\\\'application.');
insert into port_activitecitee values('35','176','(P) Réalisation de maquettes pour les différentes partie de l\\\'application. Validation des maquettes lors des réunions avec le responsable.');
insert into port_activitecitee values('35','542','Conception du design du site web à partir d\\\'un thème WordPress : Hueman');
insert into port_activitecitee values('35','544','Conception et intégration d\\\'une interface utilisateur au portail applicatif (voir cahier des charges)');
insert into port_activitecitee values('35','605','Conception de l\\\'interface de gestion des commandes. C’est un collègue qui l\\\'a ensuite développée');
insert into port_activitecitee values('35','607','Concevoir et valider la maquette en collaboration avec des utilisateurs');
insert into port_activitecitee values('35','608','Concevoir et valider la maquette en collaboration avec des utilisateurs');
insert into port_activitecitee values('35','609','Conception et développement de l\\\'interface de validation et paiemetn des fiches de frais');
insert into port_activitecitee values('36','11','Conception d\'une base de Données MySQL avec comme base d\'information, une base de données Access.');
insert into port_activitecitee values('36','80','Modification de la base de données GSB pour pouvoir y intégrer la nouvelle application.');
insert into port_activitecitee values('36','81','Modification de la base de données GSB.');
insert into port_activitecitee values('36','122','Adaptation de la base de données existante pour qu\\\'elle soir compatible avec la nouvelle application.');
insert into port_activitecitee values('36','140','Conception et déploiement de la base de données.');
insert into port_activitecitee values('36','141','Conception et déploiement de la base de données.');
insert into port_activitecitee values('36','176','(P) Création de la base de données à partir d\\\'un AGL (DBMain) : réalisation d\\\'un MCD, d\\\'un MPD et génération d\\\'un script pour MySQL.\r\nRécupération des données de la base dans l\\\'application grâce à des requêtes SQL.');
insert into port_activitecitee values('36','363','(P) Modification d\\\'une base de données déjà existante.\r\nDéveloppement d\\\'une application liée à une base de données (MySQL).');
insert into port_activitecitee values('36','406','(P) Modification d\\\'une base de données déjà existante.\r\nDéveloppement d\\\'une application liée à une base de données (MySQL).');
insert into port_activitecitee values('36','480','Création d\\\'une base de donnée PostGreSQL selon un UML donné. Adaptation de cette base aux besoins de développement.');
insert into port_activitecitee values('36','544','Adaptation d\\\'une base de données (manipulation de données, création de tables etc...) pour tests');
insert into port_activitecitee values('36','605','J\\\'ai créé la base de données sur SQL après une mise en commun des besoins de développement');
insert into port_activitecitee values('36','607','Manipulation de données');
insert into port_activitecitee values('36','608','Manipulation de données');
insert into port_activitecitee values('36','609','J\\\'ai modifié la base de données de base de gsb sur MYSQL après une mise en commun des besoins de développement');
insert into port_activitecitee values('37','80','Listages des tâches, et prévisions du temps d’exécution.');
insert into port_activitecitee values('37','140','Définition des éléments à développer.');
insert into port_activitecitee values('37','141','Définition des éléments à développer.');
insert into port_activitecitee values('37','443','Rédaction d\\\'un document descriptif de l\\\'application');
insert into port_activitecitee values('37','446','Etude du logiciel');
insert into port_activitecitee values('37','542','Définition des besoins de services à programmer liés au cahier des charges (forum, responsive, cache, SEO, ...)');
insert into port_activitecitee values('37','605','Conception du développement de la gestion des commandes');
insert into port_activitecitee values('37','607','Définition des caractéristiques de l\\\'application (documentation)');
insert into port_activitecitee values('37','608','Définition des caractéristiques de l\\\'application (documentation)');
insert into port_activitecitee values('38','81','Créations de prototype avec Netbeans, et validation par l\\\'équipe.');
insert into port_activitecitee values('39','16','Installation, configuration et utilisation de NetBeans.');
insert into port_activitecitee values('39','80','Utilisation de NetBeans PHP.');
insert into port_activitecitee values('39','81','Utilisation de NetBeans JAVA.');
insert into port_activitecitee values('39','140','Création de tests unitaires.');
insert into port_activitecitee values('39','141','Création de tests unitaires.');
insert into port_activitecitee values('39','177','Utilisation d\\\'un environnement de développement : Visual Studio.');
insert into port_activitecitee values('39','543','Mise en place de l\\\'environnement de développement et de test (Eclipse et serveur)');
insert into port_activitecitee values('39','544','Mise en place de l\\\'IDE ');
insert into port_activitecitee values('39','605','Développement réalisé avec visual studio directement lié avec Team Fondation Server.');
insert into port_activitecitee values('39','607','Mise en place et exploitation de Netbeans');
insert into port_activitecitee values('39','608','Mise en place et exploitation de Notepad++');
insert into port_activitecitee values('40','16','Développement en PHP de l\\\'environnement numérique de travail. Utilisation de Doctrine 2.');
insert into port_activitecitee values('40','80','Développement de l\\\'application GSB comptable, entièrement en PHP.');
insert into port_activitecitee values('40','81','Développement du Back-Office en JAVA.');
insert into port_activitecitee values('40','122','Développement de la nouvelle version de l\\\'application.');
insert into port_activitecitee values('40','140','Développement de l\\\'application Web.');
insert into port_activitecitee values('40','141','Développement de l\\\'application Client.');
insert into port_activitecitee values('40','177','Développement de l\\\'IHM et des fonctionnalités de l\\\'application.');
insert into port_activitecitee values('40','363','Développement de l\\\'IHM et fonctionnalités de certains formulaires de l\\\'application.');
insert into port_activitecitee values('40','406','Développement d\\\'une application web permettant de gérer les visites médicales.');
insert into port_activitecitee values('40','480','Développement du site web depuis zéro. Mise en place des fonctionnalités de base liées aux comptes (création, modification, profil)\r\nSécurité gérée par le Framework.');
insert into port_activitecitee values('40','542','Développement du site web WordPress en PHP/MySQL. Site hébergé sur 1&amp;1.');
insert into port_activitecitee values('40','543','Développement des éléments de la solution');
insert into port_activitecitee values('40','544','Développement des différentes fonctionnalités décrites par le cahier des charges');
insert into port_activitecitee values('40','605','J\\\'ai développé la partie de gestion des commandes du logiciel');
insert into port_activitecitee values('40','607','Développement d\\\'éléments de la solution');
insert into port_activitecitee values('40','608','Développement d\\\'éléments de la solution');
insert into port_activitecitee values('41','16','Test de l\\\'application au fur et a mesure que les modules sont codés.');
insert into port_activitecitee values('41','140','Réalisation des tests unitaires.');
insert into port_activitecitee values('41','141','Réalisation des tests unitaires.');
insert into port_activitecitee values('41','177','(P) Réalisation d\\\'une série de tests au fur et à mesure de l\\\'avancement de l\\\'application ainsi qu\\\'à la fin (vérification).');
insert into port_activitecitee values('41','544','Réalisation des test nécessaires à la validation et mise en place de tests unitaires');
insert into port_activitecitee values('42','14','Rédaction des procédures d\\\'installation, de configuration et d\\\'exploitation de plusieurs éléments : SNMP, FAN, Centreon, etc.');
insert into port_activitecitee values('42','79','Production d\\\'un guide d\\\'installation de l\\\'application GSB.');
insert into port_activitecitee values('42','80','Production de la documentation technique de l\\\'application.');
insert into port_activitecitee values('42','81','Rédaction de la documentation technique de l\\\'application.');
insert into port_activitecitee values('42','140','Rédaction des documentations techniques des applications.');
insert into port_activitecitee values('42','141','Rédaction des documentations techniques des applications.');
insert into port_activitecitee values('42','177','(P) Génération d\\\'une documentation technique (format HTML compilé) grâce à Visual Studio (fichier XML) et à SandCastle Help File Builder.');
insert into port_activitecitee values('42','363','(P) Génération d\\\'une documentation technique (format HTML compilé) grâce à Visual Studio (fichier XML) et à SandCastle Help File Builder.');
insert into port_activitecitee values('42','406','(P) Rédaction d\\\'une documentation technique recensant les différentes fonctionnalités de l\\\'application.');
insert into port_activitecitee values('42','429','Rédaction du cahier des charges.');
insert into port_activitecitee values('42','542','Rédaction d\\\'une documentation technique pour assurer l\\\'évolution par des développeurs tiers');
insert into port_activitecitee values('42','605','J\\\'ai rédigé un fichier word de documentation technique pour expliquer la structure du code et de la base de données');
insert into port_activitecitee values('42','607','Rédaction de documentations');
insert into port_activitecitee values('42','608','Rédaction de documentations');
insert into port_activitecitee values('42','609','J\\\'ai rédigé un fichier word de documentation technique pour expliquer la structure du code et de la base de données');
insert into port_activitecitee values('43','140','Rédaction de la notice utilisateur.');
insert into port_activitecitee values('43','141','Rédaction de la notice utilisateur.');
insert into port_activitecitee values('43','185','(P) Rédaction d\\\'une documentation utilisateur expliquant comment se servir de l\\\'application, en attirant l\\\'attention de l\\\'utilisateur sur certains points.');
insert into port_activitecitee values('43','321','(P) Rédaction d\\\'un document expliquant le travail effectué et expliquant comment utiliser une application, mise à disposition par l\\\'entreprise, pour passer la main à un autre stagiaire.');
insert into port_activitecitee values('43','363','(P) Rédaction d\\\'une documentation utilisateur expliquant comment se servir de l\\\'application, en attirant l\\\'attention de l\\\'utilisateur sur certains points.');
insert into port_activitecitee values('43','406','(P) Rédaction d\\\'une documentation utilisateur expliquant comment se servir de l\\\'application, en attirant l\\\'attention de l\\\'utilisateur sur certains points.');
insert into port_activitecitee values('43','542','Rédaction d\\\'une documentation d\\\'utilisation pour aider les employés à utiliser des fonctions plus avancées');
insert into port_activitecitee values('43','605','J\\\'ai rédigé un fichier word de documentation d\\\'utilisation pour expliquer le fonctionnement de l\\\'application');
insert into port_activitecitee values('43','609','J\\\'ai rédigé un fichier word de documentation d\\\'utilisation pour expliquer le fonctionnement de l\\\'application');
insert into port_activitecitee values('44','16','Élaboration de jeux d\\\'essai, permettant de voir et de corriger les bugs.');
insert into port_activitecitee values('44','177','(P) Correction de dysfonctionnements découverts suite aux tests réalisés.');
insert into port_activitecitee values('44','321','(P) Correction de plusieurs thèmes Wordpress avec l\\\'appui d\\\'un document.\r\n(P) Etapes de résolution des problèmes d\\\'affichage des thèmes.\r\n(P) Mise en place d\\\'un jeu d\\\'essai pour reproduire les dysfonctionnements.\r\n(P) Correction des dysfonctionnement');
insert into port_activitecitee values('44','542','Résolution de bugs tout au long du développement. Optimisation de la vitesse (cache) et du responsive');
insert into port_activitecitee values('46','16','Réalisation des tests après correction des bugs, et test de mises en production sur serveur secondaire.');
insert into port_activitecitee values('46','80','Création d\\\'un jeux d\\\'essai pour l\\\'application.');
insert into port_activitecitee values('46','81','Test de l\\\'application.');
insert into port_activitecitee values('46','607','Réalisation de tests lors des mises à jour');
insert into port_activitecitee values('46','608','Réalisation de tests lors des mises à jour');
insert into port_activitecitee values('47','542','Rajout à une documentation technique d\\\'informations lors du développement de nouveaux modules');
insert into port_activitecitee values('48','177','(P) Mise en place d\\\'une gestion de version maison : enregistrement d\\\'une version lorsqu\\\'une nouvelle partie allait être développée.');
insert into port_activitecitee values('48','363','Utilisation d\\\'un système de gestion de développement collaboratif de logiciel, Team Foundation Server, permettant de gérer les versions de l\\\'application.');
insert into port_activitecitee values('48','480','Mise en place d\\\'un système de gestion de version des fichiers : GitHub');
insert into port_activitecitee values('48','605','Mise en place d\\\'un système de gestion de version des fichiers : Team Fondation Server');
insert into port_activitecitee values('48','607','Gestion de configuration');
insert into port_activitecitee values('48','608','Gestion de configuration');
insert into port_activitecitee values('48','609','Mise en place d\\\'un système de gestion de version des fichiers : Git');
insert into port_activitecitee values('51','122','Etudes des offres de serveur d\\\'hébergement web, et choix de l\\\'une d\\\'entres elles selon les critères imposé.');
insert into port_activitecitee values('54','79','Vérification du respect des normes. Production d\\\'un document permettant de rectifier les erreurs.');
insert into port_activitecitee values('54','80','Vérification de l\\\'emploi des normes.');
insert into port_activitecitee values('54','605','Analyse d\\\'un fichier préconisant des normes de développement pour GSB. Adaptation de la manière de coder.');
insert into port_activitecitee values('54','607','Utilisation des normes courantes de développement');
insert into port_activitecitee values('54','608','Utilisation des normes courantes de développement');
insert into port_activitecitee values('54','609','Analyse d\\\'un fichier préconisant des normes de développement pour GSB. Correction du code pré-éxistant en corrélation aux standards et adaptation de la manière de coder.');
insert into port_activitecitee values('55','136','');
insert into port_activitecitee values('55','177','(P) Rédaction d\\\'un fichier contenant différentes sources d\\\'information utilisées pour le développement de l\\\'application.');
insert into port_activitecitee values('55','321','(P) Rédaction d\\\'un fichier contenant différentes sources d\\\'information utilisées pour le développement de l\\\'application.');
insert into port_activitecitee values('55','446','Veille technologique sur les logiciels de gestion de projets');
insert into port_activitecitee values('55','543','Mise en place d\\\'un processus de veille technologique des nouveaux procédés et notions abordés pendant la mission');
insert into port_activitecitee values('55','544','Mise en place d\\\'un processus de veille pour étudier les méthodes et procédés utilisés');
insert into port_activitecitee values('55','581','Recherche et mise en place d\\\'un Feedly, une extension de chrome pour agréger les flux RSS et recherche manuelle d\\\'informations clé');
insert into port_activitecitee values('55','589','Mise en place d\\\'une veille technologique');
insert into port_activitecitee values('56','581','J\\\'ai vu que j\\\'avais besoin de nouvelles connaissances grâce à la veille pour mettre en oeuvre mes objectifs professionnels');
insert into port_activitecitee values('57','16','Etude du Framework PHP Symfony 2, du moteur de Template TWIG et de l\\\'ORM Doctrine 2.');
insert into port_activitecitee values('57','122','Etude du Framework PHP Codeigniter et du Framework JavaScript HighCharts.');
insert into port_activitecitee values('57','443','Documentation du logiciel');
insert into port_activitecitee values('57','463','Rédaction d\\\'un dossier sur différents langages et technologies web et mobiles');
insert into port_activitecitee values('57','542','Etudes de divers technologies, outils, plugins WordPress (gzip, WP Super Cache, WP total cache, Rocket, etc ...)');
insert into port_activitecitee values('57','543','Etude des méthodes et outils utilisés pendant la mission');
insert into port_activitecitee values('57','544','Documentation à propos d‘une technologie, d\\\'un composant, d\\\'un outil ou d\\\'une méthode');
insert into port_activitecitee values('57','581','Apprentissage de divers technologies comme le C++, langage absolu de la programmation du jeu vidéo que l\\\'on a pas eu l\\\'occasion d\\\'aborder en cours');
CREATE TABLE `port_cadre` (
  `code` smallint(6) NOT NULL,
  `libelle` char(20) NOT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
insert into port_cadre values('1','Équipe');
insert into port_cadre values('2','Seul');
CREATE TABLE `port_commentaire` (
  `numero` int(11) NOT NULL AUTO_INCREMENT,
  `refSituation` int(11) DEFAULT NULL,
  `numProfesseur` int(11) DEFAULT NULL,
  `commentaire` varchar(255) DEFAULT NULL,
  `datecommentaire` date DEFAULT NULL,
  PRIMARY KEY (`numero`),
  KEY `icommsitu` (`refSituation`),
  CONSTRAINT `port_commentaire_ibfk_1` FOREIGN KEY (`refSituation`) REFERENCES `port_situation` (`ref`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
insert into port_commentaire values('11','112','3','Bravo !','2018-02-26');
CREATE TABLE `port_competence` (
  `id` smallint(6) NOT NULL,
  `idActivite` smallint(6) NOT NULL,
  `nomenclature` char(9) NOT NULL,
  `libelle` varchar(210) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
insert into port_competence values('1','1','C1.1.1.1','Recenser et caractériser les contextes d\'utilisation, les processus et les acteurs sur lesquels le service à produire aura un impact');
insert into port_competence values('2','1','C1.1.1.2','Identifier les fonctionnalités attendues du service à produire');
insert into port_competence values('3','1','C1.1.1.3','Préparer sa participation à une réunion');
insert into port_competence values('4','1','C1.1.1.4','Rédiger un compte-rendu d\'entretien, de réunion');
insert into port_competence values('5','2','C1.1.2.1','Analyser les interactions entre services');
insert into port_competence values('6','2','C1.1.2.2','Recenser les composants de l\'architecture technique sur lesquels le service à produire aura un impact');
insert into port_competence values('7','3','C1.1.3.1','Recenser et caractériser les exigences liées à la qualité attendue du service à produire');
insert into port_competence values('8','3','C1.1.3.2','Recenser et caractériser les exigences de sécurité pour le service à produire');
insert into port_competence values('9','4','C1.2.1.1','Recenser et caractériser des solutions répondant au cahier des charges (adaptation d\'une solution existante ou réalisation d\'une nouvelle)');
insert into port_competence values('10','4','C1.2.1.2','Estimer le coût d\'une solution');
insert into port_competence values('11','4','C1.2.1.3','Rédiger un dossier de choix et un argumentaire technique');
insert into port_competence values('12','5','C1.2.2.1','Recenser les composants nécessaires à la réalisation de la solution retenue');
insert into port_competence values('13','5','C1.2.2.2','Décrire l\'implantation des différents composants de la solution et les échanges entre eux ');
insert into port_competence values('14','5','C1.2.2.3','Rédiger les spécifications fonctionnelles et techniques de la solution retenue dans le formalisme exigé par l\'organisation');
insert into port_competence values('15','6','C1.2.3.1','Recenser les risques liés à une mauvaise utilisation ou à une utilisation malveillante du service');
insert into port_competence values('16','6','C1.2.3.2','Recenser les risques liés à un dysfonctionnement du service');
insert into port_competence values('17','6','C1.2.3.3','Prévoir les conséquences techniques de la non prise en compte d\'un risque');
insert into port_competence values('18','7','C1.2.4.1','Recenser les tests d\'acceptation nécessaires à la validation du service et les résultats attendus');
insert into port_competence values('19','7','C1.2.4.2','Préparer les jeux d\'essai et les procédures pour la réalisation des tests');
insert into port_competence values('20','8','C1.2.5.1','Recenser les utilisateurs du service, leurs rôles et leur niveau de responsabilité');
insert into port_competence values('21','8','C1.2.5.2','Recenser les ressources liées à l\'utilisation du service');
insert into port_competence values('22','8','C1.2.5.3','Proposer les niveaux d\'habilitation associés au service');
insert into port_competence values('23','9','C1.3.1.1','Mettre en place l\'environnement de test du service');
insert into port_competence values('24','9','C1.3.1.2','Tester le service');
insert into port_competence values('25','9','C1.3.1.3','Rédiger le rapport de test');
insert into port_competence values('26','10','C1.3.2.1','Identifier les éléments à sauvegarder et à journaliser pour assurer la continuité du service et la traçabilité des transactions');
insert into port_competence values('27','10','C1.3.2.2','Spécifier les procédures d\'alerte associées au service');
insert into port_competence values('28','10','C1.3.2.3','Décrire les solutions de fonctionnement en mode dégradé et les procédures de reprise du service');
insert into port_competence values('29','11','C1.3.3.1','Mettre en place l\'environnement de formation au nouveau service');
insert into port_competence values('30','11','C1.3.3.2','Informer et former les utilisateurs');
insert into port_competence values('31','12','C1.3.4.1','Mettre au point une procédure d\'installation de la solution');
insert into port_competence values('32','12','C1.3.4.2','Automatiser l\'installation de la solution ');
insert into port_competence values('33','12','C1.3.4.3','Mettre en exploitation le service');
insert into port_competence values('34','13','C1.4.1.1','Établir son planning personnel en fonction des exigences et du déroulement du projet');
insert into port_competence values('35','13','C1.4.1.2','Rendre compte de son activité');
insert into port_competence values('36','14','C1.4.2.1','Suivre l\'exécution du projet');
insert into port_competence values('37','14','C1.4.2.2','Analyser les écarts entre temps prévu et temps consommé');
insert into port_competence values('38','14','C1.4.2.3','Contribuer à l\'évaluation du projet');
insert into port_competence values('39','15','C1.4.3.1','Recenser les ressources humaines, matérielles, logicielles et budgétaires nécessaires à l\'exécution du projet et de ses tâches personnelles');
insert into port_competence values('40','15','C1.4.3.2','Adapter son planning personnel en fonction des ressources disponibles');
insert into port_competence values('41','16','C2.1.1.1','Aider les utilisateurs dans l\'appropriation du nouveau service');
insert into port_competence values('42','16','C2.1.1.2','Identifier des besoins de formation complémentaires');
insert into port_competence values('43','16','C2.1.1.3','Rendre compte de la satisfaction des utilisateurs');
insert into port_competence values('44','17','C2.1.2.1','Analyser les indicateurs de qualité du service');
insert into port_competence values('45','17','C2.1.2.2','Appliquer les procédures d\'alerte destinées à rétablir la qualité du service');
insert into port_competence values('46','17','C2.1.2.3','Vérifier périodiquement le fonctionnement du service en mode dégradé et la disponibilité des éléments permettant une reprise du service');
insert into port_competence values('47','17','C2.1.2.4','Superviser les services et leur utilisation');
insert into port_competence values('48','17','C2.1.2.5','Contrôler la confidentialité et l\'intégrité des données');
insert into port_competence values('49','17','C2.1.2.6','Exploiter les indicateurs et les fichiers d\'audit');
insert into port_competence values('50','17','C2.1.2.7','Produire les rapports d\'activité demandés par les différents acteurs');
insert into port_competence values('51','18','C2.2.1.1','Résoudre l\'incident en s\'appuyant sur une base de connaissances et la documentation associée ou solliciter l\'entité compétente');
insert into port_competence values('52','18','C2.2.1.2','Prendre le contrôle d\'un système à distance');
insert into port_competence values('53','18','C2.2.1.3','Rédiger un rapport d\'incident et mémoriser l\'incident et sa résolution dans une base de connaissances');
insert into port_competence values('54','18','C2.2.1.4','Faire évoluer une procédure de résolution d\'incident');
insert into port_competence values('55','19','C2.2.2.1','Identifier le niveau d\'assistance souhaité et proposer une réponse adaptée en s\'appuyant sur une base de connaissances et sur la documentation associée ou solliciter l\'entité compétente');
insert into port_competence values('56','19','C2.2.2.2','Informer l\'utilisateur de la situation de sa demande');
insert into port_competence values('57','19','C2.2.2.3','Prendre le contrôle d\'un poste utilisateur à distance');
insert into port_competence values('58','19','C2.2.2.4','Mémoriser la demande d\'assistance et sa réponse dans une base de connaissances');
insert into port_competence values('59','20','C2.2.3.1','Appliquer la procédure de continuité du service en mode dégradé');
insert into port_competence values('60','20','C2.2.3.2','Appliquer la procédure de reprise du service');
insert into port_competence values('61','21','C2.3.1.1','Repérer une suite de dysfonctionnements récurrents d\'un service');
insert into port_competence values('62','21','C2.3.1.2','Identifier les causes de ce dysfonctionnement');
insert into port_competence values('63','21','C2.3.1.3','Qualifier le problème (contexte et environnement)');
insert into port_competence values('64','21','C2.3.1.4','Définir le degré d\'urgence du problème');
insert into port_competence values('65','21','C2.3.1.5','Évaluer les conséquences techniques du problème');
insert into port_competence values('66','22','C2.3.2.1','Décrire les incidences d\'un changement proposé sur le service');
insert into port_competence values('67','22','C2.3.2.2','Évaluer le délai et le coût de réalisation du changement proposé');
insert into port_competence values('68','22','C2.3.2.3','Recenser les risques techniques, humains, financiers et juridiques associés au changement proposé');
insert into port_competence values('69','23','C3.1.1.1','Lister les composants matériels et logiciels nécessaires à la prise en charge des processus, des flux d\'information et de leur rôle');
insert into port_competence values('70','23','C3.1.1.2','Caractériser les éléments d\'interconnexion, les services, les serveurs et les équipements terminaux nécessaires');
insert into port_competence values('71','23','C3.1.1.3','Caractériser les éléments permettant d\'assurer la qualité et la sécurité des services');
insert into port_competence values('72','23','C3.1.1.4','Recenser les modifications et/ou les acquisitions nécessaires à la mise en place d\'une solution d\'infrastructure compatible avec le budget et le planning prévisionnels');
insert into port_competence values('73','23','C3.1.1.5','Caractériser les solutions d\'interconnexion utilisées entre un réseau et d\'autres réseaux internes ou externes à l\'organisation');
insert into port_competence values('74','24','C3.1.2.1','Concevoir une maquette de la solution');
insert into port_competence values('75','24','C3.1.2.2','Construire un prototype de la solution');
insert into port_competence values('76','24','C3.1.2.3','Préparer l\'intégration d\'un composant d\'infrastructure');
insert into port_competence values('77','25','C3.1.3.1','Caractériser des solutions de sécurité et en évaluer le coût');
insert into port_competence values('78','25','C3.1.3.2','Proposer une solution de sécurité compatible avec les contraintes techniques, financières, juridiques et organisationnelles');
insert into port_competence values('79','25','C3.1.3.3','Décrire une solution de sécurité et les risques couverts');
insert into port_competence values('80','26','C3.2.1.1','Installer et configurer un élément d\'interconnexion, un service, un serveur, un équipement terminal utilisateur');
insert into port_competence values('81','26','C3.2.1.2','Installer et configurer un élément d\'infrastructure permettant d\'assurer la continuité de service, un système de régulation des éléments d\'infrastructure, un outil de métrologie, un dispositif d\'alerte');
insert into port_competence values('82','26','C3.2.1.3','Installer et configurer des éléments de sécurité permettant d\'assurer la protection du système informatique');
insert into port_competence values('83','27','C3.2.2.1','Élaborer une procédure de remplacement ou de migration respectant la continuité d\'un service');
insert into port_competence values('84','27','C3.2.2.2','Mettre en œuvre une procédure de remplacement ou de migration');
insert into port_competence values('85','28','C3.2.3.1','Repérer les éléments de la documentation à mettre à jour');
insert into port_competence values('86','28','C3.2.3.2','Mettre à jour la documentation');
insert into port_competence values('87','29','C3.3.1.1','Installer et configurer des éléments d\'administration sur site ou à distance');
insert into port_competence values('88','29','C3.3.1.2','Administrer des éléments d\'infrastructure sur site ou à distance');
insert into port_competence values('89','30','C3.3.2.1','Installer et configurer des outils de sauvegarde et de restauration');
insert into port_competence values('90','30','C3.3.2.2','Définir des procédures de sauvegarde et de restauration');
insert into port_competence values('91','30','C3.3.2.3','Appliquer des procédures de sauvegarde et de restauration');
insert into port_competence values('92','31','C3.3.3.1','Identifier les besoins en gestion d\'identité permettant de protéger les éléments d\'une infrastructure');
insert into port_competence values('93','31','C3.3.3.2','Gérer des utilisateurs et une structure organisationnelle');
insert into port_competence values('94','31','C3.3.3.3','Affecter des droits aux utilisateurs sur les éléments d\'une solution d\'infrastructure');
insert into port_competence values('95','32','C3.3.4.1','Repérer les tâches d\'administration à automatiser');
insert into port_competence values('96','32','C3.3.4.2','Concevoir, réaliser et mettre en place une procédure d\'automatisation');
insert into port_competence values('97','33','C3.3.5.1','Installer et configurer les outils nécessaires à la production d\'indicateurs d\'activité et à l\'exploitation de fichiers d\'activité');
insert into port_competence values('98','33','C3.3.5.2','Assurer la confidentialité des informations collectées et traitées');
insert into port_competence values('99','34','C4.1.1.1','Identifier les composants logiciels nécessaires à la conception de la solution');
insert into port_competence values('100','34','C4.1.1.2','Estimer les éléments de coût et le délai de mise en œuvre de la solution');
insert into port_competence values('101','35','C4.1.2.1','Définir les spécifications de l\'interface utilisateur de la solution applicative');
insert into port_competence values('102','35','C4.1.2.2','Maquetter un élément de la solution applicative');
insert into port_competence values('103','35','C4.1.2.3','Concevoir et valider la maquette en collaboration avec des utilisateurs');
insert into port_competence values('104','36','C4.1.3.1','Modéliser le schéma de données nécessaire à la mise en place de la solution applicative');
insert into port_competence values('105','36','C4.1.3.2','Implémenter le schéma de données dans un SGBD');
insert into port_competence values('106','36','C4.1.3.3','Programmer des éléments de la solution applicative dans le langage d\'un SGBD');
insert into port_competence values('107','36','C4.1.3.4','Manipuler les données liées à la solution applicative à travers un langage de requête');
insert into port_competence values('108','37','C4.1.4.1','Recenser et caractériser les composants existants ou à développer utiles à la réalisation de la solution applicative dans le respect des budgets et planning prévisionnels');
insert into port_competence values('109','38','C4.1.5.1','Choisir les éléments de la solution à prototyper');
insert into port_competence values('110','38','C4.1.5.2','Développer un prototype');
insert into port_competence values('111','38','C4.1.5.3','Valider un prototype');
insert into port_competence values('112','39','C4.1.6.1','Mettre en place et exploiter un environnement de développement');
insert into port_competence values('113','39','C4.1.6.2','Mettre en place et exploiter un environnement de test');
insert into port_competence values('114','40','C4.1.7.1','Développer les éléments d\'une solution');
insert into port_competence values('115','40','C4.1.7.2','Créer un composant logiciel');
insert into port_competence values('116','40','C4.1.7.3','Analyser et modifier le code d\'un composant logiciel');
insert into port_competence values('117','40','C4.1.7.4','Utiliser des composants d\'accès aux données');
insert into port_competence values('118','40','C4.1.7.5','Mettre en place des éléments de sécurité liés à l\'utilisation d\'un composant logiciel');
insert into port_competence values('119','41','C4.1.8.1','Élaborer et réaliser des tests unitaires');
insert into port_competence values('120','41','C4.1.8.2','Mettre en évidence et corriger les écarts');
insert into port_competence values('121','42','C4.1.9.1','Produire ou mettre à jour la documentation technique d\'une solution applicative et de ses composants logiciels');
insert into port_competence values('122','43','C4.1.10.1','Rédiger la documentation d\'utilisation, une aide en ligne, une FAQ');
insert into port_competence values('123','43','C4.1.10.2','Adapter la documentation d\'utilisation à chaque contexte d\'utilisation');
insert into port_competence values('124','44','C4.2.1.1','Élaborer un jeu d\'essai permettant de reproduire le dysfonctionnement');
insert into port_competence values('125','44','C4.2.1.2','Repérer les composants à l\'origine du dysfonctionnement');
insert into port_competence values('126','44','C4.2.1.3','Concevoir les mises à jour à effectuer');
insert into port_competence values('127','44','C4.2.1.4','Réaliser les mises à jour');
insert into port_competence values('128','45','C4.2.2.1','Repérer les évolutions des composants utilisés et leurs conséquences');
insert into port_competence values('129','45','C4.2.2.2','Concevoir les mises à jour à effectuer');
insert into port_competence values('130','45','C4.2.2.3','Élaborer et réaliser les tests unitaires des composants mis à jour');
insert into port_competence values('131','46','C4.2.3.1','Élaborer et réaliser des tests d\'intégration et de non régression de la solution mise à jour');
insert into port_competence values('132','46','C4.2.3.2','Concevoir une procédure de migration et l\'appliquer dans le respect de la continuité de service');
insert into port_competence values('133','47','C4.2.4.1','Repérer les éléments de la documentation à mettre à jour');
insert into port_competence values('134','47','C4.2.4.2','Mettre à jour une documentation');
insert into port_competence values('135','48','C5.1.1.1','Recenser les caractéristiques techniques nécessaires à la gestion des éléments de la configuration d\'une organisation');
insert into port_competence values('136','48','C5.1.1.2','Paramétrer une solution de gestion des éléments d\'une configuration');
insert into port_competence values('137','49','C5.1.2.1','Renseigner les événements relatifs au cycle de vie d\'un élément de la configuration');
insert into port_competence values('138','49','C5.1.2.2','Actualiser les caractéristiques des éléments de la configuration');
insert into port_competence values('139','50','C5.1.3.1','Contrôler et auditer les éléments de la configuration');
insert into port_competence values('140','50','C5.1.3.2','Reconstituer un historique des modifications effectuées sur les éléments de la configuration');
insert into port_competence values('141','50','C5.1.3.3','Identifier les éléments de la configuration à modifier ou à remplacer');
insert into port_competence values('142','50','C5.1.3.4','Repérer les équipements obsolètes et en proposer le traitement dans le respect de la réglementation en vigueur');
insert into port_competence values('143','51','C5.1.4.1','Assister la maîtrise d\'ouvrage dans l\'analyse technique de la proposition de contrat');
insert into port_competence values('144','51','C5.1.4.2','Interpréter des indicateurs de suivi de la prestation associée à la proposition de contrat');
insert into port_competence values('145','51','C5.1.4.3','Renseigner les éléments permettant d\'estimer la valeur du service');
insert into port_competence values('146','52','C5.1.5.1','Vérifier un plan d\'amortissement');
insert into port_competence values('147','52','C5.1.5.2','Apprécier la valeur actuelle d\'un élément de configuration');
insert into port_competence values('148','53','C5.1.6.1','Renseigner les variables d\'une étude de rentabilité d\'un investissement');
insert into port_competence values('149','53','C5.1.6.2','Caractériser et prévoir les investissements matériels et logiciels');
insert into port_competence values('150','54','C5.2.1.1','Évaluer le degré de conformité des pratiques à un référentiel, à une norme ou à un standard adopté par le prestataire informatique');
insert into port_competence values('151','54','C5.2.1.2','Identifier et partager les bonnes pratiques à intégrer');
insert into port_competence values('152','55','C5.2.2.1','Définir une stratégie de recherche d\'informations');
insert into port_competence values('153','55','C5.2.2.2','Tenir à jour une liste de sources d\'information');
insert into port_competence values('154','55','C5.2.2.3','Évaluer la qualité d\'une source d\'information en fonction d\'un besoin');
insert into port_competence values('155','55','C5.2.2.4','Synthétiser et diffuser les résultats d\'une veille');
insert into port_competence values('156','56','C5.2.3.1','Identifier les besoins de formation pour mettre en œuvre une technologie, un composant, un outil ou une méthode');
insert into port_competence values('157','56','C5.2.3.2','Repérer l\'offre et les dispositifs de formation');
insert into port_competence values('158','57','C5.2.4.1','Se documenter à propos d‘une technologie, d\'un composant, d\'un outil ou d\'une méthode');
insert into port_competence values('159','57','C5.2.4.2','Identifier le potentiel et les limites d\'une technologie, d\'un composant, d\'un outil ou d\'une méthode par rapport à un service à produire');
CREATE TABLE `port_domaine` (
  `id` smallint(6) NOT NULL,
  `idProcessus` smallint(6) NOT NULL,
  `nomenclature` char(4) NOT NULL,
  `libelle` varchar(60) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
insert into port_domaine values('1','1','D1.1','Analyse de la demande');
insert into port_domaine values('2','1','D1.2','Choix d\'une solution');
insert into port_domaine values('3','1','D1.3','Mise en production d\'un service');
insert into port_domaine values('4','1','D1.4','Travail en mode projet');
insert into port_domaine values('5','2','D2.1','Exploitation des services');
insert into port_domaine values('6','2','D2.2','Gestion des incidents et des demandes d\'assistance');
insert into port_domaine values('7','2','D2.3','Gestion des problèmes et des changements');
insert into port_domaine values('8','3','D3.1','Conception d\'une solution d\'infrastructure');
insert into port_domaine values('9','3','D3.2','Installation d\'une solution d\'infrastructure');
insert into port_domaine values('10','3','D3.3','Administration et supervision d\'une infrastructure');
insert into port_domaine values('11','4','D4.1','Conception et réalisation d\'une solution applicative');
insert into port_domaine values('12','4','D4.2','Maintenance d\'une solution applicative');
insert into port_domaine values('13','5','D5.1','Gestion des configurations');
insert into port_domaine values('14','5','D5.2','Gestion des compétences');
CREATE TABLE `port_epreuve` (
  `id` smallint(6) NOT NULL,
  `nomenclature` char(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
insert into port_epreuve values('1','U4');
insert into port_epreuve values('2','U5');
insert into port_epreuve values('3','U6');
CREATE TABLE `port_esttypo` (
  `refSituation` int(11) NOT NULL DEFAULT '0',
  `codeTypologie` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`refSituation`,`codeTypologie`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
insert into port_esttypo values('14','1');
insert into port_esttypo values('14','3');
insert into port_esttypo values('16','1');
insert into port_esttypo values('81','3');
insert into port_esttypo values('112','2');
insert into port_esttypo values('112','3');
insert into port_esttypo values('122','1');
insert into port_esttypo values('122','2');
insert into port_esttypo values('136','4');
insert into port_esttypo values('140','1');
insert into port_esttypo values('140','3');
insert into port_esttypo values('141','1');
insert into port_esttypo values('141','3');
insert into port_esttypo values('166','2');
insert into port_esttypo values('166','3');
insert into port_esttypo values('176','3');
insert into port_esttypo values('177','1');
insert into port_esttypo values('177','3');
insert into port_esttypo values('185','3');
insert into port_esttypo values('321','4');
insert into port_esttypo values('363','1');
insert into port_esttypo values('363','3');
insert into port_esttypo values('406','1');
insert into port_esttypo values('406','3');
insert into port_esttypo values('429','3');
insert into port_esttypo values('442','2');
insert into port_esttypo values('446','4');
insert into port_esttypo values('463','3');
insert into port_esttypo values('480','1');
insert into port_esttypo values('542','1');
insert into port_esttypo values('542','2');
insert into port_esttypo values('542','3');
insert into port_esttypo values('543','1');
insert into port_esttypo values('543','4');
insert into port_esttypo values('544','1');
insert into port_esttypo values('544','3');
insert into port_esttypo values('544','4');
insert into port_esttypo values('581','4');
insert into port_esttypo values('589','4');
insert into port_esttypo values('605','1');
insert into port_esttypo values('605','3');
insert into port_esttypo values('607','1');
insert into port_esttypo values('607','3');
insert into port_esttypo values('608','1');
insert into port_esttypo values('608','3');
insert into port_esttypo values('609','1');
insert into port_esttypo values('609','3');
CREATE TABLE `port_etudiant` (
  `num` int(11) NOT NULL AUTO_INCREMENT,
  `numGroupe` int(11) DEFAULT NULL,
  `nom` char(32) NOT NULL,
  `prenom` char(32) NOT NULL,
  `mel` char(64) NOT NULL,
  `mdp` char(32) NOT NULL,
  `numexam` char(16) DEFAULT NULL,
  `valide` char(1) NOT NULL DEFAULT 'O',
  PRIMARY KEY (`num`),
  KEY `ietudgrou` (`numGroupe`)
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8;
insert into port_etudiant values('7','2','Grimal','Matthieu','slam@icof.fr','12345678','','O');
insert into port_etudiant values('23','3','Scheibli','Auguste','sisr@icof.fr','12345678','','O');
insert into port_etudiant values('35','2','Moreira','Liliana','liliana.moreira@icof.fr','12345678','','O');
insert into port_etudiant values('75','2','delay','anthony','anthony.delay@icof.fr','12345678','','O');
insert into port_etudiant values('76','2','diab','nicolas','nicolas.diab@icof.fr','12345678','','O');
insert into port_etudiant values('77','2','testeur','Matthieu','testeur.mathieu@icof.fr','12345678','','O');
CREATE TABLE `port_evalue` (
  `idParcours` smallint(6) NOT NULL DEFAULT '0',
  `idEpreuve` smallint(6) NOT NULL DEFAULT '0',
  `idActivite` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`idParcours`,`idEpreuve`,`idActivite`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
insert into port_evalue values('0','1','5');
insert into port_evalue values('0','1','7');
insert into port_evalue values('0','1','9');
insert into port_evalue values('0','1','12');
insert into port_evalue values('0','1','18');
insert into port_evalue values('0','1','19');
insert into port_evalue values('0','1','20');
insert into port_evalue values('0','1','24');
insert into port_evalue values('0','1','26');
insert into port_evalue values('0','1','27');
insert into port_evalue values('0','1','28');
insert into port_evalue values('0','1','29');
insert into port_evalue values('0','1','32');
insert into port_evalue values('0','1','33');
insert into port_evalue values('0','1','35');
insert into port_evalue values('0','1','36');
insert into port_evalue values('0','1','38');
insert into port_evalue values('0','1','39');
insert into port_evalue values('0','1','40');
insert into port_evalue values('0','1','41');
insert into port_evalue values('0','1','42');
insert into port_evalue values('0','1','43');
insert into port_evalue values('0','1','44');
insert into port_evalue values('0','1','45');
insert into port_evalue values('0','1','46');
insert into port_evalue values('0','1','47');
insert into port_evalue values('0','2','1');
insert into port_evalue values('0','2','2');
insert into port_evalue values('0','2','3');
insert into port_evalue values('0','2','4');
insert into port_evalue values('0','2','6');
insert into port_evalue values('0','2','8');
insert into port_evalue values('0','2','10');
insert into port_evalue values('0','2','21');
insert into port_evalue values('0','2','22');
insert into port_evalue values('0','2','23');
insert into port_evalue values('0','2','25');
insert into port_evalue values('0','2','30');
insert into port_evalue values('0','2','31');
insert into port_evalue values('0','2','34');
insert into port_evalue values('0','2','37');
insert into port_evalue values('0','2','52');
insert into port_evalue values('0','2','53');
insert into port_evalue values('0','3','11');
insert into port_evalue values('0','3','13');
insert into port_evalue values('0','3','14');
insert into port_evalue values('0','3','15');
insert into port_evalue values('0','3','16');
insert into port_evalue values('0','3','17');
insert into port_evalue values('0','3','48');
insert into port_evalue values('0','3','49');
insert into port_evalue values('0','3','50');
insert into port_evalue values('0','3','51');
insert into port_evalue values('0','3','54');
insert into port_evalue values('0','3','55');
insert into port_evalue values('0','3','56');
insert into port_evalue values('0','3','57');
insert into port_evalue values('1','1','5');
insert into port_evalue values('1','1','7');
insert into port_evalue values('1','1','9');
insert into port_evalue values('1','1','12');
insert into port_evalue values('1','1','18');
insert into port_evalue values('1','1','19');
insert into port_evalue values('1','1','20');
insert into port_evalue values('1','1','24');
insert into port_evalue values('1','1','26');
insert into port_evalue values('1','1','27');
insert into port_evalue values('1','1','28');
insert into port_evalue values('1','1','29');
insert into port_evalue values('1','1','32');
insert into port_evalue values('1','1','33');
insert into port_evalue values('1','2','1');
insert into port_evalue values('1','2','2');
insert into port_evalue values('1','2','3');
insert into port_evalue values('1','2','4');
insert into port_evalue values('1','2','6');
insert into port_evalue values('1','2','8');
insert into port_evalue values('1','2','10');
insert into port_evalue values('1','2','21');
insert into port_evalue values('1','2','22');
insert into port_evalue values('1','2','23');
insert into port_evalue values('1','2','25');
insert into port_evalue values('1','2','30');
insert into port_evalue values('1','2','31');
insert into port_evalue values('1','2','52');
insert into port_evalue values('1','2','53');
insert into port_evalue values('1','3','11');
insert into port_evalue values('1','3','13');
insert into port_evalue values('1','3','14');
insert into port_evalue values('1','3','15');
insert into port_evalue values('1','3','16');
insert into port_evalue values('1','3','17');
insert into port_evalue values('1','3','48');
insert into port_evalue values('1','3','49');
insert into port_evalue values('1','3','50');
insert into port_evalue values('1','3','51');
insert into port_evalue values('1','3','54');
insert into port_evalue values('1','3','55');
insert into port_evalue values('1','3','56');
insert into port_evalue values('1','3','57');
insert into port_evalue values('2','1','5');
insert into port_evalue values('2','1','7');
insert into port_evalue values('2','1','9');
insert into port_evalue values('2','1','12');
insert into port_evalue values('2','1','18');
insert into port_evalue values('2','1','19');
insert into port_evalue values('2','1','20');
insert into port_evalue values('2','1','35');
insert into port_evalue values('2','1','36');
insert into port_evalue values('2','1','38');
insert into port_evalue values('2','1','39');
insert into port_evalue values('2','1','40');
insert into port_evalue values('2','1','41');
insert into port_evalue values('2','1','42');
insert into port_evalue values('2','1','43');
insert into port_evalue values('2','1','44');
insert into port_evalue values('2','1','45');
insert into port_evalue values('2','1','46');
insert into port_evalue values('2','1','47');
insert into port_evalue values('2','2','1');
insert into port_evalue values('2','2','2');
insert into port_evalue values('2','2','3');
insert into port_evalue values('2','2','4');
insert into port_evalue values('2','2','6');
insert into port_evalue values('2','2','8');
insert into port_evalue values('2','2','10');
insert into port_evalue values('2','2','21');
insert into port_evalue values('2','2','22');
insert into port_evalue values('2','2','34');
insert into port_evalue values('2','2','37');
insert into port_evalue values('2','2','52');
insert into port_evalue values('2','2','53');
insert into port_evalue values('2','3','11');
insert into port_evalue values('2','3','13');
insert into port_evalue values('2','3','14');
insert into port_evalue values('2','3','15');
insert into port_evalue values('2','3','16');
insert into port_evalue values('2','3','17');
insert into port_evalue values('2','3','48');
insert into port_evalue values('2','3','49');
insert into port_evalue values('2','3','50');
insert into port_evalue values('2','3','51');
insert into port_evalue values('2','3','54');
insert into port_evalue values('2','3','55');
insert into port_evalue values('2','3','56');
insert into port_evalue values('2','3','57');
CREATE TABLE `port_exerce` (
  `numProfesseur` int(11) NOT NULL,
  `numGroupe` int(11) NOT NULL,
  PRIMARY KEY (`numProfesseur`,`numGroupe`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
insert into port_exerce values('1','1');
insert into port_exerce values('3','2');
insert into port_exerce values('3','3');
CREATE TABLE `port_exploite` (
  `idParcours` smallint(6) NOT NULL DEFAULT '0',
  `idProcessus` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`idParcours`,`idProcessus`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
insert into port_exploite values('1','1');
insert into port_exploite values('1','2');
insert into port_exploite values('1','3');
insert into port_exploite values('1','5');
insert into port_exploite values('2','1');
insert into port_exploite values('2','2');
insert into port_exploite values('2','4');
insert into port_exploite values('2','5');
CREATE TABLE `port_groupe` (
  `num` int(11) NOT NULL AUTO_INCREMENT,
  `nom` char(12) DEFAULT NULL,
  `annee` char(2) DEFAULT NULL,
  `idParcours` smallint(6) DEFAULT '0',
  PRIMARY KEY (`num`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
insert into port_groupe values('1','admins','00','0');
insert into port_groupe values('2','modeleSLAM','00','2');
insert into port_groupe values('3','modeleSISR','00','1');
CREATE TABLE `port_localisation` (
  `code` smallint(6) NOT NULL,
  `libelle` char(32) NOT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
insert into port_localisation values('1','Organisation');
insert into port_localisation values('2','Centre de formation');
CREATE TABLE `port_parcours` (
  `id` smallint(6) NOT NULL,
  `nomenclature` char(4) NOT NULL,
  `libelle` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
insert into port_parcours values('0','****','Indifférencié');
insert into port_parcours values('1','SISR','Solutions d’infrastructure, systèmes et réseaux');
insert into port_parcours values('2','SLAM','solutions logicielles et applications métiers');
CREATE TABLE `port_processus` (
  `id` smallint(6) NOT NULL,
  `nomenclature` char(2) NOT NULL,
  `libelle` varchar(60) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
insert into port_processus values('1','P1','Production de services');
insert into port_processus values('2','P2','Fourniture de services');
insert into port_processus values('3','P3','Conception et maintenance de solutions d’infrastructure');
insert into port_processus values('4','P4','Conception et maintenance de solutions applicatives');
insert into port_processus values('5','P5','Gestion du patrimoine informatique');
CREATE TABLE `port_production` (
  `numero` int(11) NOT NULL AUTO_INCREMENT,
  `refSituation` int(11) NOT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `adresse` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`numero`),
  KEY `iprodsitu` (`refSituation`),
  CONSTRAINT `port_production_ibfk_1` FOREIGN KEY (`refSituation`) REFERENCES `port_situation` (`ref`)
) ENGINE=InnoDB AUTO_INCREMENT=1103 DEFAULT CHARSET=utf8;
insert into port_production values('8','14','A1.1.1 : Analyse du cahier des charges','http://agst.sch.overblog.com/a1-1-1-analyse-du-cahier-des-charges-d-un-service-a-produire');
insert into port_production values('10','14','A1.1.3 : Étude des exigences liées à la qualité attendue d\\\'un service ','http://agst.sch.overblog.com/a1-1-3-etude-des-exigences-liees-a-la-qualite-attendue-d-un-service');
insert into port_production values('11','14','A1.2.2 Rédaction des spécifications techniques de la solution retenue (adaptation d\\\'une solution existante ou réalisation d\\\'une nouvelle solution) ','http://agst.sch.overblog.com/a1-2-2-redaction-des-specifications-techniques-de-la-solution-retenue-adaptation-d-une-solution-existante-ou-realisation-d-une-nouvelle');
insert into port_production values('12','14','A1.2.3 Évaluation des risques liés à l\\\'utilisation d\\\'un service ','http://agst.sch.overblog.com/a1-2-3-evaluation-des-risques-lies-a-l-utilisation-d-un-service');
insert into port_production values('13','14','A1.3.1 Test d\\\'intégration et d\\\'acceptation d\\\'un service ','http://agst.sch.overblog.com/a1-3-1-test-d-integration-et-d-acceptation-d-un-service');
insert into port_production values('14','14','A1.3.3 Accompagnement de la mise en place d\\\'un nouveau service ','http://agst.sch.overblog.com/a1-3-3-accompagnement-de-la-mise-en-place-d-un-nouveau-service');
insert into port_production values('15','14','A1.4.2 Évaluation des indicateurs de suivi d\\\'un projet et justification des écarts ','http://agst.sch.overblog.com/a1-4-2-evaluation-des-indicateurs-de-suivi-d-un-projet-et-justification-des-ecarts');
insert into port_production values('16','14','A1.4.3 Gestion des ressources ','http://agst.sch.overblog.com/a1-4-3-gestion-des-ressources');
insert into port_production values('17','14','A2.1.2 Évaluation et maintien de la qualité d\\\'un service ','http://agst.sch.overblog.com/a2-1-2-evaluation-et-maintien-de-la-qualite-d-un-service');
insert into port_production values('18','14','A3.3.1 Administration sur site ou à distance des éléments d\\\'un réseau, de serveurs, de services et d\\\'équipements terminaux ','http://agst.sch.overblog.com/a3-3-1-administration-sur-site-ou-a-distance-des-elements-d-un-reseau-de-serveurs-de-services-et-d-equipements-terminaux');
insert into port_production values('19','14','A3.3.5 Gestion des indicateurs et des fichiers d\\\'activité ','http://agst.sch.overblog.com/a3-3-5-gestion-des-indicateurs-et-des-fichiers-d-activite');
insert into port_production values('20','14','A4.1.9 Rédaction d\\\'une documentation technique ','http://agst.sch.overblog.com/a4-1-9-redaction-d-une-documentation-technique');
insert into port_production values('27','11','Rapport de Stage','http://saya-irino.fr/ICOF/Rapport%20de%20Stage.pdf');
insert into port_production values('28','16','Rapport de Stage','http://saya-irino.fr/ICOF/Rapport%20de%20Stage.pdf');
insert into port_production values('71','122','Rapport de Stage','http://saya-irino.fr/ICOF/Rapport%20de%20Stage%202.pdf');
insert into port_production values('73','122','Planning','http://saya-irino.fr/ICOF/planning.xlsx');
insert into port_production values('74','122','Traitement de bug','http://saya-irino.fr/ICOF/RE%20ent%20%C3%A0%20nouveau%20impossible%20de%20mettre%20des%20commentaires%20dans%20l\\\'offre%20et%20%C3%A0%20partir%20de%20la%20liste%20devis%20%C3%A0%20faire.htm');
insert into port_production values('75','122','Traitement de Bug','http://saya-irino.fr/ICOF/RE%20ent%20commentaires%20sur%20affaires%20en%20s%C3%A9lection%20pas%20sur%20la%20bonne%20affaire%20.htm');
insert into port_production values('76','122','Base de données','http://saya-irino.fr/ICOF/bdd.svg');
insert into port_production values('77','122','Maquette d\\\'Interface','http://saya-irino.fr/ICOF/gerant_v1.png');
insert into port_production values('78','122','Trigger','http://saya-irino.fr/ICOF/trigger%20tranche.sql');
insert into port_production values('79','122','Trigger','http://saya-irino.fr/ICOF/trigger%20tranche%20update.sql');
insert into port_production values('80','79','Notes sur les normes de développement','http://saya-irino.fr/ICOF/PPE0/Grimal%20-%20Note%20Normes.docx');
insert into port_production values('81','79','Tuto d\\\'installation','http://saya-irino.fr/ICOF/PPE0/Grimal%20-%20Tutos%20install%20appli.docx');
insert into port_production values('82','80','Documentation technique','http://saya-irino.fr/ICOF/PPE1/Documentation%20Technique%20GSB%20-%20Team%20B.docx');
insert into port_production values('83','80','Gantt','http://saya-irino.fr/ICOF/PPE1/GSB%20Gantt%20-%20Team%20B.xlsx');
insert into port_production values('85','80','Tâches à effectuer','http://saya-irino.fr/ICOF/PPE1/T%c3%a2ches%20%c3%a0%20effectu%c3%a9es%20-%20Richard,%20Sok,%20Grimal.docx');
insert into port_production values('86','81','Jeu d\\\'essai','http://saya-irino.fr/ICOF/PPE2/Fiche%20test%20visualition%20TEAM%20B.docx');
insert into port_production values('87','81','Tâches à effectuer','http://saya-irino.fr/ICOF/PPE2/GSB2%20-%20T%c3%a2ches%20-%20Team%20B.docx');
insert into port_production values('88','81','Maquette','http://saya-irino.fr/ICOF/PPE2/Gestion%20visiteurs.png');
insert into port_production values('89','81','Jeu d\\\'essai','http://saya-irino.fr/ICOF/PPE2/Jeux%20d\\\'essai%20secteur.docx');
insert into port_production values('90','81','Tâches à effectuer','http://saya-irino.fr/ICOF/PPE2/T%c3%a2ches%20TEAM%20B.xlsx');
insert into port_production values('91','81','Documentation technique','http://saya-irino.fr/ICOF/PPE2/doc%20gestion%20visiteurs%20-%20Team%20B.docx');
insert into port_production values('92','81','Jeu d\\\'essai','http://saya-irino.fr/ICOF/PPE2/fiche%20test%20gestion%20visiteurs%20-%20Team%20B.docx');
insert into port_production values('93','81','Maquette','http://saya-irino.fr/ICOF/PPE2/secteur_add_edit_list.png');
insert into port_production values('94','81','Maquette','http://saya-irino.fr/ICOF/PPE2/secteur_affectation.png');
insert into port_production values('95','81','Maquette','http://saya-irino.fr/ICOF/PPE2/visualisation%20des%20frais.png');
insert into port_production values('105','112','A3.3.3 Gestion des identités et des habilitations','http://agst.sch.overblog.com/a3.3.3-gestion-des-identit%C3%A9s-et-des-habilitations');
insert into port_production values('106','112','A3.3.1 Administration sur site ou à distance des éléments d\\\'un réseau, de serveurs, de services et d\\\'équipements terminaux','http://agst.sch.overblog.com/a3.3.1-administration-sur-site-ou-%C3%A0-distance-des-%C3%A9l%C3%A9ments-d-un-r%C3%A9seau-de-serveurs-de-services-et-d-%C3%A9quipements-terminaux');
insert into port_production values('107','112','A2.2.2 Suivi et réponse à des demandes d\\\'assistance','http://agst.sch.overblog.com/a2.2.2-suivi-et-r%C3%A9ponse-%C3%A0-des-demandes-d-assistance');
insert into port_production values('108','112','A2.2.1 Suivi et résolution d\\\'incidents','http://agst.sch.overblog.com/a2.2.1-suivi-et-r%C3%A9solution-d-incidents');
insert into port_production values('155','166','A2.2.1 Suivi et résolution d\\\'incidents','http://agst.sch.overblog.com/a2.2.1-suivi-et-r%C3%A9solution-d-incidents');
insert into port_production values('156','166','A3.3.1 Administration sur site ou à distance des éléments d\\\'un réseau, de serveurs, de services et d\\\'équipements terminaux','http://agst.sch.overblog.com/a3.3.1-administration-sur-site-ou-%C3%A0-distance-des-%C3%A9l%C3%A9ments-d-un-r%C3%A9seau-de-serveurs-de-services-et-d-%C3%A9quipements-terminaux');
insert into port_production values('159','136','Netvibes','http://www.netvibes.com');
insert into port_production values('163','140','Cas d\\\'utilisation textuelle','http://saya-irino.fr/ICOF/E4/Situation%201/Cas_Utilisation_Web.docx');
insert into port_production values('164','140','Diagramme de cas d\\\'utilisation','http://saya-irino.fr/ICOF/E4/Situation%201/Cas_Utilisation_Web.vsdx');
insert into port_production values('165','140','Description','http://saya-irino.fr/ICOF/E4/Situation%201/Epreuve%20E4.docx');
insert into port_production values('166','140','Jeux d\\\'essai','http://saya-irino.fr/ICOF/E4/Situation%201/Jeux%20d\\\'essai.docx');
insert into port_production values('167','140','Spécifications Techniques','http://saya-irino.fr/ICOF/E4/Situation%201/Sp%c3%a9cifications%20Techniques.docx');
insert into port_production values('168','140','MCD','http://saya-irino.fr/ICOF/E4/Situation%201/bdd.png');
insert into port_production values('169','140','Script SQL','http://saya-irino.fr/ICOF/E4/Situation%201/creabas.sql');
insert into port_production values('170','141','Diagramme de cas d\\\'utilisation','http://saya-irino.fr/ICOF/E4/Situation%202/Diagramme%20de%20cas%20d\\\'utilisation.vsdx');
insert into port_production values('171','141','Description','http://saya-irino.fr/ICOF/E4/Situation%202/Epreuve%20E4.docx');
insert into port_production values('172','141','Spécifications Techniques','http://saya-irino.fr/ICOF/E4/Situation%202/Sp%c3%a9cifications%20Techniques.docx');
insert into port_production values('173','141','MCD','http://saya-irino.fr/ICOF/E4/Situation%202/bdd.png');
insert into port_production values('174','141','Script SQL','http://saya-irino.fr/ICOF/E4/Situation%202/crebas.sql');
insert into port_production values('223','16','Documentation Symfony 2','http://symfony.com/doc/current/index.html');
insert into port_production values('229','122','Documentation CodeIgniter','http://codeigniter.fr/user_guide/index.html');
insert into port_production values('230','122','Rapport de Stage Annexes','http://saya-irino.fr/ICOF/Rapport%20de%20stage%202%20annexe.pdf');
insert into port_production values('273','79','CDC','http://saya-irino.fr/ICOF/GSB-FicheDescriptive.doc');
insert into port_production values('274','80','CDC','http://saya-irino.fr/ICOF/GSB-FicheDescriptive.doc');
insert into port_production values('275','81','CDC','http://saya-irino.fr/ICOF/GSB-FicheDescriptive.doc');
insert into port_production values('286','176','A1.1.1 Analyse du cahier des charges d\\\'un service à produire','https://www.dropbox.com/s/1qks8kwcjcbyje4/Doc%20-%20Analyse%20des%20besoins.pdf');
insert into port_production values('288','176','A1.1.1 Analyse du cahier des charges d\\\'un service à produire (fichiers Excel)','https://www.dropbox.com/s/zbl4y2s5epm2d8z/Doc%20-%20Fichiers%20Excel%20de%20base.pdf');
insert into port_production values('289','176','A1.2.2 Rédaction des spécifications techniques de la solution retenue','https://www.dropbox.com/s/uo3ykmzrh9y914n/Doc%20-%20Sp%C3%A9cifications%20techniques.pdf');
insert into port_production values('291','177','A1.4.1 Participation à un projet','https://www.dropbox.com/s/o43jj0vz0ubycam/Doc%20-%20Planning.pdf');
insert into port_production values('292','177','A4.1.8 Réalisation des tests nécessaires à la validation d\\\'éléments adaptés ou développés','https://www.dropbox.com/s/tp1wa57raij9r4q/Doc%20-%20Tests.pdf');
insert into port_production values('293','177','A4.1.9 Rédaction d\\\'une documentation technique','https://www.dropbox.com/sh/waguajrh023z7ja/k3bFoephic');
insert into port_production values('295','185','A4.1.1 Rédaction d\\\'une documentation d\\\'utilisation','https://www.dropbox.com/s/b3hshj4sniy0m98/Doc%20-%20Documentation%20utilisateur%202.0.pdf');
insert into port_production values('297','177','A4.2.1 Analyse et correction d\\\'un dysfonctionnement, d\\\'un problème de qualité de service ou de sécurité','https://www.dropbox.com/s/rlki2agtaaxu67z/Doc%20-%20Probl%C3%A8mes%20%C3%A0%20r%C3%A9soudre.pdf');
insert into port_production values('304','177','A5.1.1 Mise en place d\\\'une gestion de configuration','https://www.dropbox.com/sh/r4hponbiviaelhc/5vcKjpgrcD');
insert into port_production values('403','176','A4.1.2 Conception ou adaptation de l\\\'interface utilisateur d\\\'une solution applicative (maquettes)','https://www.dropbox.com/sh/mjld8m99x6jaoic/egEhoO88iv');
insert into port_production values('419','177','A5.2.2 Veille technologique','https://www.dropbox.com/s/nqjd66ns7qtt02p/Doc%20-%20Veille%20technologique.pdf');
insert into port_production values('449','321','A1.1.3 Étude des exigences liées à la qualité attendue d\\\'un service','https://www.dropbox.com/s/96ufchgl8bausg4/Doc%20-%20Liste%20des%20t%C3%A2ches.pdf');
insert into port_production values('450','321','A1.4.1 Participation à un projet','https://www.dropbox.com/sh/jdays6tog7dv4e4/eLmXhWaBi3');
insert into port_production values('451','321','A4.1.1 Rédaction d\\\'une documentation d\\\'utilisation','https://www.dropbox.com/s/2zcg7xh2z7mprty/Doc%20-%20R%C3%A9f%C3%A9rencement%20des%20sites%20Accord%20Services.pdf');
insert into port_production values('452','321','A4.2.1 (Documentation charte) Analyse et correction d\\\'un dysfonctionnement, d\\\'un problème de qualité de service ou de sécurité','https://www.dropbox.com/s/kp67mtwfabku2ks/Doc%20-%20Chartes%20migr%C3%A9es%20correction.pdf');
insert into port_production values('453','321','A4.2.1 (Résolution chartes) Analyse et correction d\\\'un dysfonctionnement, d\\\'un problème de qualité de service ou de sécurité','https://www.dropbox.com/s/gy9uv7dafeii6zw/Doc%20-%20Modifications%20chartes%20KUD.pdf');
insert into port_production values('454','321','A4.2.1 (Jeux d\\\'essai Callback) Analyse et correction d\\\'un dysfonctionnement, d\\\'un problème de qualité de service ou de sécurité','https://www.dropbox.com/s/h7vsklug0b36s0r/Doc%20-%20Modifications%20Callback%20et%20jeux%20d%27essai.pdf');
insert into port_production values('464','363','A1.1.1 Analyse du cahier des charges d\\\'un service à produire','https://www.dropbox.com/s/drcmiovsj4ryk0x/Doc%20-%20Cahier%20des%20charges.pdf');
insert into port_production values('465','363','A1.1.1 Analyse du cahier des charges d\\\'un service à produire (tâches à réaliser)','https://www.dropbox.com/s/i0akjrui9aqt7ve/Doc%20-%20T%C3%A2ches%20%C3%A0%20r%C3%A9aliser.pdf');
insert into port_production values('466','363','A4.1.3 Conception ou adaptation d\\\'une base de données','https://www.dropbox.com/sh/xbrvca1ndqxhwu6/ZK5t8dx-dV');
insert into port_production values('467','363','A4.1.9 Rédaction d\\\'une documentation technique','https://www.dropbox.com/s/0dzoi098j1627xx/Aper%C3%A7u%20-%20Documentation%20technique.jpg');
insert into port_production values('494','321','A4.2.1 (Corrections Callback) Analyse et correction d\\\'un dysfonctionnement, d\\\'un problème de qualité de service ou de sécurité','https://www.dropbox.com/sh/s6ern7e9f67ccg3/WB1CgwrAnL');
insert into port_production values('495','321','A5.2.2 Veille technologique','https://www.dropbox.com/s/e611pfdmfq82w0k/Doc%20-%20Veille%20technologique.pdf');
insert into port_production values('565','176','A4.1.3 Conception ou adaptation d\\\'une base de données','https://www.dropbox.com/sh/17p75nutvolyw2a/a90_5j1qJG');
insert into port_production values('599','406','A1.1.1 Analyse du cahier des charges d\\\'un service à produire (cahier des charges)','https://www.dropbox.com/s/khz48of9c52si56/GSB_Cahier_des_charges.pdf');
insert into port_production values('600','406','A1.1.1 Analyse du cahier des charges d\\\'un service à produire (résumé du cahier des charges)','https://www.dropbox.com/s/beonm7k2jgcgnxl/R%C3%A9sum%C3%A9_cahier_des_charges.pdf');
insert into port_production values('601','406','A4.1.3 Conception ou adaptation d\\\'une base de données','https://www.dropbox.com/sh/qj7ay9g6xwpu3sw/wlUMIg2UNY');
insert into port_production values('602','406','A4.1.9 Rédaction d\\\'une documentation technique','https://www.dropbox.com/s/910dpkoftujovf5/MOREIRA_Documentation_Technique.pdf');
insert into port_production values('603','406','A4.1.10 Rédaction d\\\'une documentation d\\\'utilisation','https://www.dropbox.com/s/vzc0x1o0tv8hu4o/MOREIRA_Documentation_Utilisateur.pdf');
insert into port_production values('616','363','A4.1.1 Rédaction d\\\'une documentation d\\\'utilisation','https://www.dropbox.com/s/xlmgu42k3ovue53/Doc%20-%20Documentation%20utilisateur.pdf');
insert into port_production values('656','429','Rapport de modifications et description des différentes versions','https://lyceeicof-my.sharepoint.com/personal/anthony_delay_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=BWjQnfsZe3zZt%2fUo77X7GJZJMdXpWipft79JMPjHVxI%3d&amp;docid=006dae29b4fc84d018cc4d6e46f853202');
insert into port_production values('660','442','Assistance problème de messagerie','https://lyceeicof-my.sharepoint.com/personal/anthony_delay_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=ybkun8bZJ5xIk4TdF%2f8AjqdXO7kxSiAlwNjK7ZbFGgk%3d&amp;docid=003cd590018134dfd86a1adac2378feed');
insert into port_production values('661','443','Etude utilisation d’une solution logicielle et risques','https://lyceeicof-my.sharepoint.com/personal/anthony_delay_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=yknU2TwIzNEantx7JNpgSJQrymN%2b7Jp6O8a6kw7xW9s%3d&amp;docid=04139a69054be44a1af3b6b22395e13ab');
insert into port_production values('662','444','Script de message d\\\'accueil aléatoires','https://lyceeicof-my.sharepoint.com/personal/anthony_delay_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=4EzYH6C%2bjYWmDY2nP%2bD3anp5UYhpqX46tHUha1cnn9g%3d&amp;docid=0803c99dc903d40558e0ad2368bada63d');
insert into port_production values('664','446','Tutoriel d\\\'utilisation de GanttProject','https://lyceeicof-my.sharepoint.com/personal/anthony_delay_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=9XveovHI7bImqQeEACudV8RtSw1ULMouZSw3AaZ3PsE%3d&amp;docid=0ae66974205ba4d50bc38e69b82687d0c');
insert into port_production values('665','446','Veille technologique sur les logiciels de gestion de projets','https://lyceeicof-my.sharepoint.com/personal/anthony_delay_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=0xHs8%2bxRXjp413lpyCBbtn5KflfkJUcmsLDNg1fHQhk%3d&amp;docid=05888ff4fac524a9191d2c2835329fd2d');
insert into port_production values('675','463','Fichier de Benchmark','https://lyceeicof-my.sharepoint.com/personal/nicolas_diab_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=Yrw6qEfeUevdJmu5qyUe9L1Tb9MU5XVnlbJyyzkxziI%3d&amp;docid=0417115f507c7487cb01d4c1a6fb687ce');
insert into port_production values('677','480','Code source du projet - github','https://github.com/NicolasDiab/pimble-site');
insert into port_production values('734','480','Document de présentation du code','https://lyceeicof-my.sharepoint.com/personal/nicolas_diab_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=ZTgrqa3MWlMe2N5nff4KfZc7v1K5GbJIhmCYWWI83a0%3d&amp;docid=04950534e4eed40279afd304d13126896');
insert into port_production values('736','480','UML reçu de mon maître de stage','https://lyceeicof-my.sharepoint.com/personal/nicolas_diab_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=IBzFKldDa2lRAvhj43cxggAmgW3rN4h794XwZ97dLsQ%3d&amp;docid=0dfccbd2e505244e6bf19f24a288b27c5');
insert into port_production values('812','543','Cahier des charges de l\\\'application (éditeurs)','https://lyceeicof-my.sharepoint.com/personal/anthony_delay_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=aozKDxCk4ma82chTObO8Eq7rs0%2buf%2bJoLzSiv9j%2f75E%3d&amp;docid=04a47be30b4e44c3ea3ee8dd24c7c533b');
insert into port_production values('817','543','Veille technologique','https://lyceeicof-my.sharepoint.com/personal/anthony_delay_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=XX4suamtG2f2tMM1EkeQjg70nSXVviERBkiF%2bwyhJL8%3d&amp;docid=0a548702336c148dd9156c6106ad34186');
insert into port_production values('818','543','Rapport d\\\'activités','https://lyceeicof-my.sharepoint.com/personal/anthony_delay_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=HO%2bpkrjOf0tjLVY2ildwJ9XkR94lOAEQVXBnaq6egm8%3d&amp;docid=09b7eb245e98546878305ab8fcfd023dc');
insert into port_production values('819','543','Code source du connecteur ','https://lyceeicof-my.sharepoint.com/personal/anthony_delay_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=97vR3wgbYMJgvbUdf3HSzeaAku%2buNQyDzK88ZG4kesc%3d&amp;docid=0a4dd055839ed48fcaed8f33eac71f864');
insert into port_production values('820','543','Fichier WSDL','https://lyceeicof-my.sharepoint.com/personal/anthony_delay_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=Ni%2fqHeDOgbkMQdZgWo4r%2bLOPeStG8auNvLq7MCue3KU%3d&amp;docid=055d0744489c54ac7a442a7be738db936');
insert into port_production values('821','543','Code source classe de test','https://lyceeicof-my.sharepoint.com/personal/anthony_delay_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=um1dffQPYojqA7%2bspnlRgwRV8nStu5rydssXwzo8aY8%3d&amp;docid=0e6995bb7898e4f1f857e16f4436e9354');
insert into port_production values('822','542','Présentation de l\\\'entreprise - Ukronium1828','https://lyceeicof-my.sharepoint.com/personal/nicolas_diab_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=iWov27wgEKnted2U%2bjk%2f2MBGavixsalfT%2fnXn%2b3ZUhg%3d&amp;docid=014188d0281fc4435a7e3785512b21a05');
insert into port_production values('823','542','Planning','https://lyceeicof-my.sharepoint.com/personal/nicolas_diab_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=FlpcU7ZyHEygOm8depmYPW0GPspXsHQ2bGbhir%2b5eWQ%3d&amp;docid=06e95e13ce1884180a3b4a5418ccd1b41');
insert into port_production values('824','542','Aspect de l\\\'ancien site d\\\'Ukronium1828 (dossier .zip)','https://lyceeicof-my.sharepoint.com/personal/nicolas_diab_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=LRf08G%2ftvJqiFjh1RzTl3rEVH4uYV7rxMjh6uVIaNPE%3d&amp;docid=0c5eb249b957847c1bcbf54922c004c08');
insert into port_production values('825','542','Nouveau site d\\\'Ukronium1828 que j\\\'ai créé','http://www.ukronium1828.fr/');
insert into port_production values('826','542','Cahier des charges rédigé','https://lyceeicof-my.sharepoint.com/personal/nicolas_diab_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=0t4f2TWPkhTZFg1M5ywEiOEK09bnyZV7uZIA3hkWhnI%3d&amp;docid=0d9fd95cd72314369b90c49de5afd6826');
insert into port_production values('827','542','Rapport d\\\'activité hebdomadaire','https://lyceeicof-my.sharepoint.com/personal/nicolas_diab_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=X8ttVMoOgzdDrakgdzDLiby2s4WmXz7DxXdX16%2flc9E%3d&amp;docid=0899502cdfdb841819dd78a55c7eb400b');
insert into port_production values('828','542','Documentation d\\\'utilisation','https://lyceeicof-my.sharepoint.com/personal/nicolas_diab_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=hlp3wQ7Ww9qlS%2bjqDyFxuHfxDFxXm0%2bxuMsY6V4GeQ0%3d&amp;docid=04a47b55bfaa647cfb425ac6dc2a52067');
insert into port_production values('829','544','Présentation du portail applicatif de l\\\'entreprise','https://lyceeicof-my.sharepoint.com/personal/anthony_delay_icof_fr/_layouts/15/WopiFrame.aspx?sourcedoc=%7B36B7401D-43B1-46A3-844A-976DF30A88D0%7D&amp;file=vanilla.docx&amp;action=default');
insert into port_production values('830','544','Cahier des charges du designer','https://lyceeicof-my.sharepoint.com/personal/anthony_delay_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=bBPKRuNLdAM1NYFv3PBkDT0rO5lPdNibBRAFfxvxIM4%3d&amp;docid=00c9072b2105e4377aaf6c78c658072de');
insert into port_production values('831','544','Captures d\\\'écran de l\\\'interface utilisateur du designer','https://lyceeicof-my.sharepoint.com/personal/anthony_delay_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=gfnewBX5FI1Mt6kNqoiymGT846yGXHsWBCNHLr%2bqUYA%3d&amp;docid=0132e9560acda4cb481d4b1a510c4e19d');
insert into port_production values('832','544','Fichiers de configs de la plateforme','https://lyceeicof-my.sharepoint.com/personal/anthony_delay_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=%2b%2bepg8BbyxcRnXZeyuD4YKb%2fF4eTDtPFYtfDST95P60%3d&amp;docid=0dffe42b9a4bf48e780f0c1d9f20f5301');
insert into port_production values('833','544','Codes sources du wizard du designer de carte et de l\\\'interface graphique','https://lyceeicof-my.sharepoint.com/personal/anthony_delay_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=IGRqSwYRls9NlO0%2ba2yTYVFiUum6whszoBO0sBO9Wjk%3d&amp;docid=0f9bcf3c1085a4a60a0ce21558af49fe7');
insert into port_production values('834','544','Script javascript de la prévisualisation de carte','https://lyceeicof-my.sharepoint.com/personal/anthony_delay_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=KcOOul0Y1sU0IJWDFMOeiGao1SsQWXPskuOmQufusjY%3d&amp;docid=01de8b7933c25425aa83213c4009307b9');
insert into port_production values('835','544','Codes sources (fichiers de classe) des relations avec les bases de données','https://lyceeicof-my.sharepoint.com/personal/anthony_delay_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=CBbgtiIaRJ1UvgRz6NLaldrhlOgKOxwLiG3VD7e6vZg%3d&amp;docid=04329477bccf64b9a986ff4995791087e');
insert into port_production values('836','544','Rapport d\\\'activités','https://lyceeicof-my.sharepoint.com/personal/anthony_delay_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=HO%2bpkrjOf0tjLVY2ildwJ9XkR94lOAEQVXBnaq6egm8%3d&amp;docid=09b7eb245e98546878305ab8fcfd023dc');
insert into port_production values('837','544','Veille technologique','https://lyceeicof-my.sharepoint.com/personal/anthony_delay_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=XX4suamtG2f2tMM1EkeQjg70nSXVviERBkiF%2bwyhJL8%3d&amp;docid=0a548702336c148dd9156c6106ad34186');
insert into port_production values('847','542','Documentation technique','https://lyceeicof-my.sharepoint.com/personal/nicolas_diab_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=vKLT7gyejKwUVwt2oHj4pyvqNX76ocIwCgP69DP27Rg%3d&amp;docid=0a1d544907ce1493ea85eaeff03339bc5');
insert into port_production values('848','542','Aide à la reprise du forum pour un employé Ukronium','https://lyceeicof-my.sharepoint.com/personal/nicolas_diab_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=KUi3pa5CcGi%2fahOEkLhTTYml6tsTHltpATqzGD1QE64%3d&amp;docid=071934e258f1549949130aadc07897039');
insert into port_production values('949','429','Annuaire version de base (1.0) - code','https://lyceeicof-my.sharepoint.com/personal/anthony_delay_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=UWeQtKys1i9IClUi9H5E4W2T3Wu%2bGIoTC5lnU3YSsS8%3d&amp;docid=09ff5f5d641704d3c86ef6d722c362ce2');
insert into port_production values('950','429','Annuaire version de base (2.0) - code','https://lyceeicof-my.sharepoint.com/personal/anthony_delay_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=lH7LsqZKXm%2bBhTjVyOYiflMMRQMUAPR4et84YZcfG1c%3d&amp;docid=0b9afe31e521b4e10867315dda989a558');
insert into port_production values('951','429','Annuaire version de base (3.0) - code','https://lyceeicof-my.sharepoint.com/personal/anthony_delay_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=DHXpeUrqNmsG94TzeFL2luy9jhDw5Fy3QBw2J5WsvJM%3d&amp;docid=075a9f2f86c384825915019329f02a308');
insert into port_production values('957','589','Résumé veille technologique','https://lyceeicof-my.sharepoint.com/personal/anthony_delay_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=QneG2QPOaP1s0i0tGXSXlW8%2bRiq0hI1WWUNN%2fUTE4Ps%3d&amp;docid=01a5c2c9758974a1aac782fcb5221264a');
insert into port_production values('1063','543','Fichier XSD','https://lyceeicof-my.sharepoint.com/personal/anthony_delay_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=rwCGCgV1hTk3QmHErL%2bOa3k85O4Hkb9SqIU0bOaIa3c%3d&amp;docid=0f76d12da10ad46aa8ef9a633bde25415');
insert into port_production values('1065','605','Documentation technique BDD','https://lyceeicof-my.sharepoint.com/personal/nicolas_diab_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=4linomvT9c2NEoXS0KtC1ZjjGq4f%2b5cZP7mJ3zB6qwk%3d&amp;docid=053ea481e97fd4e338182e4c67bf739ae');
insert into port_production values('1066','605','Documentation technique gestion commandes','https://lyceeicof-my.sharepoint.com/personal/nicolas_diab_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=SYOgQwoYKM47L7Y5pFlGSFFquIbS%2f9MEz4nnD8zcPtA%3d&amp;docid=02fed8730eb2e4523bf3e224c16ebc99d');
insert into port_production values('1067','605','Documentation d\\\'utilisation','https://lyceeicof-my.sharepoint.com/personal/nicolas_diab_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=jAgaq44s3SnQDKQObD5LUT0oFLOMGFsR3bbgvZPyWbw%3d&amp;docid=019a2d40d7f994e70a6fea81650edcd44');
insert into port_production values('1071','607','Gantt','https://lyceeicof-my.sharepoint.com/personal/anthony_delay_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=SZVUlzpaJnaVQGKlIlSDr8E8HZ2dIi4K4RCzrQzAA40%3d&amp;docid=05ed722b7e6fc44ff895cd41d4b941610');
insert into port_production values('1072','607','Doc technique BDD','https://lyceeicof-my.sharepoint.com/personal/anthony_delay_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=tMFwlZrGmkid8R3mSxX%2fdEyqzio9b7Hoy4NOO%2bJzTIU%3d&amp;docid=0b5deee6bf84e4ef4b7365b6b62a195db');
insert into port_production values('1073','607','Doc technique','https://lyceeicof-my.sharepoint.com/personal/anthony_delay_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=7vyriispVcbYeJrw9RcCJkPoLmpWGpGkbEHtM%2buJ6j4%3d&amp;docid=0817b3c40a1a540d08f2f072f3c3b6696');
insert into port_production values('1074','607','Doc d\\\'utilisation','https://lyceeicof-my.sharepoint.com/personal/anthony_delay_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=0lBO%2biAWP2h3r24X7tCzRbR8P9LDzEAiWSCQ45kprWY%3d&amp;docid=0cb842f7703a345fda83433969a4b0178');
insert into port_production values('1075','608','Doc technique BDD','https://lyceeicof-my.sharepoint.com/personal/anthony_delay_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=2U03YTr8VCpu2jAOz%2baQk7pHa36IPnZ%2fbOi3w5NfOHI%3d&amp;docid=03b4f21d7e411457999212f7594c3c3f9');
insert into port_production values('1076','608','Doc technique générale','https://lyceeicof-my.sharepoint.com/personal/anthony_delay_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=9FN74WY9WNBK%2ftGhi4j3%2bl787bhcxKl9GqUGjkNK%2b8s%3d&amp;docid=057b736e70da04d58854476d21a90d420');
insert into port_production values('1077','608','Doc d\\\'utilisation','https://lyceeicof-my.sharepoint.com/personal/anthony_delay_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=oQnzWA%2fvjgWJvpy9t%2ffjhgMryDn5tmcOc4ImYIiKwG4%3d&amp;docid=0be59565c6c0c4b22be41af55e3274e65');
insert into port_production values('1078','608','Gantt','https://lyceeicof-my.sharepoint.com/personal/anthony_delay_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=F69jW4udazjMbPPPieyiAfi3sMz9IHmRxZtuzP2gi7A%3d&amp;docid=0d7d4b1fd37de40f49cbc24909fb55864');
insert into port_production values('1079','609','Cahier des charges reçu (.pdf à télécharger)','https://lyceeicof-my.sharepoint.com/personal/nicolas_diab_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=6so3kBzSVKOlx5ExSiggmIBEXukAqvtje10ZiRWnLIo%3d&amp;docid=02b2ba86fdbbe4dfd8180de3ec82d06c2');
insert into port_production values('1080','609','Accès au site web développé (se connecter avec dandre / oppg5)','http://172.17.21.13/cAccueil.php');
insert into port_production values('1081','609','Documentation d\\\'utilisation','https://lyceeicof-my.sharepoint.com/personal/nicolas_diab_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=FqGIg%2bwI%2bxwpDKn9iQLXZjdG4q1if8cmxWujwa50mWs%3d&amp;docid=0cc011aa9e972492390a11093bfd06f20');
insert into port_production values('1082','609','Documentation technique générale','https://lyceeicof-my.sharepoint.com/personal/nicolas_diab_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=g3SnVwDsWaEgsMVL4e5lKYuXLkhfrB2RK%2be%2fRIjDB90%3d&amp;docid=0c53b585c3ce04e4484d26351d47c75ab');
insert into port_production values('1083','609','Documentation technique BDD','https://lyceeicof-my.sharepoint.com/personal/nicolas_diab_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=f0ZEXyvR%2fC50YZDBE4E5MpqxkppG%2falKLWyMfb9xxqs%3d&amp;docid=05d188cb9439b44d3806768620cc8d59c');
insert into port_production values('1084','605','Cahier des charges reçu (.pdf à télécharger)','https://lyceeicof-my.sharepoint.com/personal/nicolas_diab_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=Kn5I28AGPAIQrRzJWonU%2fPUxgGh9cEAx2aA%2bwiSemyE%3d&amp;docid=0a01971b76480414699e7ece384a69a25');
insert into port_production values('1085','609','Contexte GSB','https://lyceeicof-my.sharepoint.com/personal/nicolas_diab_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=8zSySRQCEAvK8cXEBgyO%2bHf5H7iQAZU8hp%2b2Spl1yEY%3d&amp;docid=094e0e676e7e840f29061c18b093840e3');
insert into port_production values('1086','609','Fichier des normes','https://lyceeicof-my.sharepoint.com/personal/nicolas_diab_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=7bGJpPnnfbN4MLW9hzA9B6s0roPfEyRaDJ4RrVvLJ6s%3d&amp;docid=014feaba41e9d4375ab707837d454ed6a');
insert into port_production values('1089','608','Cahier des charges','https://lyceeicof-my.sharepoint.com/personal/anthony_delay_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=93AgZbU0u3QgBHxnB6YVyCVzzQEjOjcnQ4afb2GfynM%3d&amp;docid=0c6576e617be34a1d9fc2d05054fe9039');
insert into port_production values('1090','608','Normes de développement','https://lyceeicof-my.sharepoint.com/personal/anthony_delay_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=Bf9f8uPQr28l2nkULI8VFc5G5s%2fMl56J%2bnexTbDcWRM%3d&amp;docid=01c6940d0ceb942bd86d5623d84b4c12a');
insert into port_production values('1091','608','Contexte','https://lyceeicof-my.sharepoint.com/personal/anthony_delay_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=IDp%2b4uA7r1wzDq%2fA%2bsC3d5Ajghi5T8Yt4if6AZieG64%3d&amp;docid=088876453c65b4e7d8bd581b244bb1370');
insert into port_production values('1092','608','Accès à l\\\'application','http://172.17.21.13/cSeConnecter.php');
insert into port_production values('1099','607','Cahier des charges ','https://lyceeicof-my.sharepoint.com/personal/anthony_delay_icof_fr/_layouts/15/guestaccess.aspx?guestaccesstoken=xWtMIAkKsnnvJ%2bQoIHZZLL2BuTddw1Gy%2b2VBPu5ntuo%3d&amp;docid=062d7539e2e1846ffb507381b0dd6179c');
insert into port_production values('1100','1327','jyjuloiùp*^p','htjyulopio^p)$*');
insert into port_production values('1101','1327','ui^ùpo','jlkjlmkjmkjmkjlk');
insert into port_production values('1102','1327','hygj','jhjghjgk');
CREATE TABLE `port_professeur` (
  `num` int(11) NOT NULL AUTO_INCREMENT,
  `nom` char(32) NOT NULL,
  `prenom` char(32) NOT NULL,
  `mel` char(64) NOT NULL,
  `mdp` char(32) NOT NULL,
  `niveau` int(11) NOT NULL,
  `valide` char(1) DEFAULT 'O',
  PRIMARY KEY (`num`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
insert into port_professeur values('3','Accary-Barbier','Tiphaine','tiphaine.accary-barbier@icof.fr','12345678','1','O');
insert into port_professeur values('7','admin','','admin@local.fr','12345678','0','O');
CREATE TABLE `port_situation` (
  `ref` int(11) NOT NULL AUTO_INCREMENT,
  `numEtudiant` int(11) NOT NULL,
  `codeLocalisation` smallint(6) NOT NULL,
  `codeSource` smallint(6) NOT NULL,
  `codeType` smallint(6) NOT NULL,
  `codeCadre` smallint(6) NOT NULL,
  `libcourt` varchar(64) NOT NULL,
  `descriptif` varchar(255) NOT NULL,
  `contexte` varchar(255) DEFAULT NULL,
  `datedebut` date DEFAULT NULL,
  `datefin` date DEFAULT NULL,
  `environnement` varchar(255) DEFAULT NULL,
  `moyen` varchar(255) DEFAULT NULL,
  `avisperso` varchar(255) DEFAULT NULL,
  `valide` char(1) NOT NULL DEFAULT 'O',
  `datemodif` date DEFAULT NULL,
  PRIMARY KEY (`ref`),
  KEY `isituetud` (`numEtudiant`),
  KEY `isitulibc` (`libcourt`),
  CONSTRAINT `port_situation_ibfk_1` FOREIGN KEY (`numEtudiant`) REFERENCES `port_etudiant` (`num`)
) ENGINE=InnoDB AUTO_INCREMENT=1328 DEFAULT CHARSET=utf8;
insert into port_situation values('11','7','1','1','1','1','Conception d\'une base de données','Conception d\'une nouvelle base de données MySQL, depuis une base Access.','Développement de l\'environnement numérique de travail d\'exalta.','2012-05-28','2012-07-13','Power AMC, Serveur local xampp','','','O','2018-02-27');
insert into port_situation values('14','23','1','1','1','2','Outil de supervision de réseau - Nagios/Centreon','L\\\'objectif était de mettre en place une platefrome de supervision basée sur Centreon/Nagios pour être alerté de toutes anomalie sur le réseau interne de l\\\'entreprise, afin de développer une meilleure réactivité.','Stage effectué au sein de l\\\'entreprise Materne\r\nEtude de cas réalisé dans le cadre du stage de première année BTS SIO.','2012-05-29','2012-06-29','Les outils sur lesquels je me suis basé sont : un ordinateur portable permettant l\\\'accès à distance d\\\'un hyperviseur.\r\n','Voici les moyens qui m\\\'ont été mis à disposition : des schémas réseaux de l\\\'entreprise, l\\\'accès au compte administrateur, un bureau pour travailler, un logiciel de prise en main à distance, des procédures, un accès à internet, une assistance en cas de ','Sujet très intéressant','O','2013-05-09');
insert into port_situation values('16','7','1','1','1','1','Développement d\\\'une application Web','Développement de l\\\'environnement numérique de travail d\\\'exalta.\r\nCodage en PHP avec le framework Symdony 2.','Développement de l\\\'environnement numérique de travail.','2012-05-28','2012-07-13','Netbeans, plateforme local xampp.','','','O','2013-05-22');
insert into port_situation values('79','7','2','4','1','1','PPE 0','Travail sur le contexte GSB.\r\nInstallation du contexte en local\r\nProduction d’un guide d’installation\r\nTravail sur les normes de développement : production d’un document\r\nCréation de la base de données à partir d’un fichier Excel (csv) contenant les mises','GSB','2013-01-06','2013-01-06','Word, Notepad++, Windows 7, Excel, XAMPP','','','O','2013-05-22');
insert into port_situation values('80','7','2','4','1','1','PPE 1','Développement de l\\\'application Comptable GSB.\r\nLister et chiffrer les tâches à effectuer (document à produire par équipe)\r\nDévelopper les fonctionnalités « clôture » et « validation »\r\nDocument à rendre : Dossier technique des modifications effectuées (s','GSB','2013-01-06','2013-01-06','Netbeans PHP, XAMPP, Word','','','O','2013-05-22');
insert into port_situation values('81','7','2','4','1','1','PPE 2','Création du Back-Office permettant de gérer les visiteurs.\r\nLister et chiffrer les tâches à effectuer (document à produire par équipe)\r\nProposer une maquette des différents écrans ou pages\r\nDévelopper les fonctionnalités « gestion des visiteurs » et « sta','GSB','2013-01-06','2013-01-06','Netbeans JAVA, Git','','','O','2013-05-22');
insert into port_situation values('112','23','1','2','1','1','Support helpdesk - utilisateur','Des activités diverses et variées ont été effectuées lors du deuxième stage sur la base d\\\'incidents et de demandes d\\\'utilisateurs','Stage effectué au sein de l\\\'entreprise Materne\r\nActivités réalisées dans le cadre du stage de deuxième année BTS SIO','2013-01-21','2013-03-01','La communication avec les utilisateurs se faisait via téléphone ou \\&quot;ticket\\&quot; GLPI; \r\nLogiciels utilisés : VMware vCenter, LogMeIn, GLPI, etc.','Voici les moyens qui m\\\'ont été mis à disposition : compte administrateur, un bureau avec un téléphone pour le service helpdesk, un logiciel de prise en main à distance, des procédures, un accès à internet, une assistance en cas de besoin par les employés','Sujet moyennement intéressant mais capacités personnelles améliorées','O','2013-05-09');
insert into port_situation values('122','7','1','2','1','1','Stage 2ème année','Amélioration d\\\'un solution existante.\r\nModification de la base de données.\r\nDéveloppement de la nouvelle application.','Stage de 2ème années.','2013-01-21','2013-02-22','XAMPP, Mutualisé OVH, SQL Privé OVH, MySQL, Microsoft Windows 8, Microsoft WebMatrix, MySQL Workbench, Sybase PowerAMC, Google Chrome.','','','O','2013-05-21');
insert into port_situation values('136','7','2','4','1','2','Mise en place d\\\'un dispositif de veille technologique','Mise en place d\\\'un dispositif de veille technologique grâces à un suivis des flux RSS.','','2012-09-03','2013-06-28','Windows','Netvibes','','O','2018-03-01');
insert into port_situation values('140','7','2','4','1','2','E4 : Applications CR','Développement des application de comptes rendus pour visiteur, dans le cadre de l\\\'épreuve orale , dans le contexte GSB.','GSB','2013-04-14','2013-04-14','Microsoft Windows 8, Microsoft Windows 7, Microsoft Windows Server 2012, Apache','Visual Studio 2012, Serveur Apache, Microsoft SQL Server 2012, Sublime Text 2','','O','2013-05-20');
insert into port_situation values('141','7','2','4','1','2','E4 : Back Office','Application de Back Office pour le Laboratoire, dans le cadre de l\\\'épreuve orale , dans le contexte GSB.','GSB','2013-04-14','2013-04-14','Microsoft Windows 8, Microsoft Windows 7, Microsoft Windows Server 2012','Visual Studio 2012, Microsoft SQL Server 2012','','O','2013-05-20');
insert into port_situation values('166','23','1','2','1','1','Support helpdesk - Manipulation de serveurs','Des activités diverses et variées ont été effectuées lors du deuxième stage sur la base d\\\'incidents et de demandes d\\\'utilisateurs suite à des anomalies sur des serveurs','Stage effectué au sein de l\\\'entreprise Materne\r\nActivités réalisées dans le cadre du stage de deuxième année BTS SIO','2013-01-21','2013-03-01','Les serveurs étaient pour l\\\'ensemble virtualisés ; \r\nLogiciels utilisés : VMware vCenter, LogMeIn,GLPI etc.','Voici les moyens qui m\\\'ont été mis à disposition : compte administrateur, un bureau avec un téléphone pour le service helpdesk, un logiciel de prise en main à distance, des procédures, un accès à internet, une assistance en cas de besoin par les employés','Sujet moyennement intéressant mais capacités personnelles améliorées','O','2013-05-09');
insert into port_situation values('176','35','1','1','1','2','IXEO - Organisation et gestion de données','Etude des fonctionnalités attendues pour l\\\'application à développer.\r\nCréation d\\\'une base de données.','Stage 1ère année chez IXEO.','2013-05-21','2013-06-21','Ordinateur portable personnel sous W7, Visual Studio 2010, UWamp, DBMain, connexion Internet et une imprimante.','Compétences techniques et théoriques.','','O','2014-05-28');
insert into port_situation values('177','35','1','1','1','2','IXEO - Développement d\\\'une application C#','Développement d\\\'une application de gestion de factures en C#.','Stage 1ère année chez IXEO.','2013-05-21','2013-06-21','Ordinateur portable personnel sous W7, Visual Studio 2010, UWamp, connexion Internet.','Compétences techniques et théoriques.','','O','2014-05-28');
insert into port_situation values('185','35','1','1','1','2','IXEO - Déploiement d\\\'application','Déploiement de la base de données et de l\\\'application.\r\n(architecture : client lourd)','Stage 1ère année chez IXEO.','2013-05-21','2013-06-21','Ordinateur portable personnel sous W7, ordinateur du responsable, Visual Studio 2010, connexion Internet.','','','O','2014-05-28');
insert into port_situation values('321','35','1','2','1','2','KUBIWEB - Référencement et maintenance de sites','Amélioration du référencement de plusieurs sites internet afin de les faire monter dans les résultats de recherche Google.\r\nCorrection de thèmes Wordpress et d\\\'une application web.','','2014-01-06','2014-02-21','Ordinateur portable personnel sous W7, UWamp, Wordpress.','','','O','2014-05-28');
insert into port_situation values('363','35','2','4','1','1','PPE C# - Développement d\\\'un back-office','Développement d’un outil de gestion des visiteurs médicaux.','','2013-11-08','2013-12-13','Ordinateur fixe sous W8, Visual Studio 2010, UWamp.','','','O','2014-05-28');
insert into port_situation values('406','35','2','4','1','2','PPE PHP - Développement d\\\'une application web','Développement d\\\'une application permettant aux visiteurs de gérer les visites chez des praticiens : consultation et saisie de compte-rendus, consultation des médicaments et des praticiens.','','2014-03-21','2014-05-23','Ordinateur fixe sous W8, NetBeans, UWamp.','','','O','2014-05-28');
insert into port_situation values('429','75','1','1','1','2','Stage 1 - Modification de la page d\\\'annuaire du site du CADEC','Élaboration d\\\'un rapport en vue des modifications de l\\\'annuaire du site et mise en place de celles-ci.\r\nMise en oeuvre de ces modifications.\r\n','Stage de première année au CADEC','2014-05-19','2014-05-26','Backoffice de l\\\'entreprise (application CMS), NotePad++, Windows 8','','','O','2015-03-19');
insert into port_situation values('442','75','1','1','1','2','Stage 1 - Prise en charge d’incidents et assistance','Assistance problème messagerie de l\\\'entreprise','Stage de première année au CADEC','2014-05-27','2014-05-28','Microsoft Windows 8','','','O','2015-03-19');
insert into port_situation values('443','75','1','1','1','2','Stage 1 - Etude d\\\'une solution applicative','Etude d\\\'utilisation d’une solution logicielle et risques','Stage première année au CADEC','2014-05-29','2014-06-02','Microsoft Windows 8, logiciel A2GI-LOCATION : gestion de locations','','','O','2015-03-19');
insert into port_situation values('444','75','1','1','1','2','Stage 1 - Intégration et conception d\\\'un script','Conception d\\\'un script permettant l\\\'affichage de messages d\\\'accueil aléatoires sur le site.','Stage première année au CADEC','2014-06-03','2014-06-05','Microsoft Windows 8, Notepad++, serveur Uwamp, backofffice du site','','','O','2015-03-19');
insert into port_situation values('446','75','1','1','1','2','Stage 1 - Intégration et suivi d\\\'une solution applicative','Veille technologique logiciels gestion de projets,\r\nIntégration de la solution, rédaction de tutoriel d\\\'utilisation, Suivi des utilisateurs, présentation à l\\\'équipe','Stage première année au CADEC','2014-06-09','2014-06-23','Microsoft Windows 8, logiciel GanttProject, Google Chrome, Microsoft Word','','','O','2015-03-19');
insert into port_situation values('463','76','1','1','1','2','Stage 1- Élaboration d\\\'un dossier de choix de solution techniqu','Etude de différentes technologies web et mobiles et langages afin d\\\'orienter les choix de l\\\'entreprise pour la création d\\\'un site web et d\\\'une application mobile.','Stage première année','2014-05-19','2014-05-30','Google','Etude réalisée à la bibliothèque universitaire de l\\\'INSA, proche du lieu de stage.','','O','2015-03-19');
insert into port_situation values('480','76','1','1','1','1','Stage 1- Production d\\\'un site web','Création d\\\'un site web en Python, étant orienté selon les directives de mon maître de stage et accompagné d\\\'un autre stagiaire qui s\\\'occupait de la charte graphique','Stage première année','2014-06-02','2014-07-03','Python, Django, PostGreSQL, GitHub, could9 IDE','Développement effectué depuis chez moi en télétravail','','O','2015-03-24');
insert into port_situation values('542','76','1','2','1','2','Stage 2 - Réalisation d\\\'un site web WordPress','Rédaction d\\\'un cahier des charges, réflexion, conception, rédactions de documentations, élaboration du design, formation utilisateurs, sécurité et référencement, correction de bugs','Stage de deuxième année chez Ukronium1828','2015-01-05','2015-02-16','WordPress, notepad++','','Expérience intéressante, j\\\'ai toujours voulu apprendre WordPress','O','2015-04-28');
insert into port_situation values('543','75','1','2','1','2','Stage 2 - Développement et déploiement d\\\'un webservice','Développement de WebServices de test pour un EAI développé pour un des clients de l\\\'entreprise, qui avaient pour but de retourner des informations médicales (tels que les passages aux urgences) en fonction de paramètres (code établissement, date, etc…).','Stage de deuxième année à BPM-Conseil','2015-01-05','2015-01-09','Eclipse Kepler v4.3, Windows Seven, Serveur TomCat, Java/GWT','','','O','2015-03-19');
insert into port_situation values('544','75','1','2','1','2','Stage 2 - Création d\\\'un designer de définition de cartes','Développement d’un outil de définition cartographique intégré au portail applicatif. Il comprend un assistant de création de définition cartographique ainsi que la définition de sources et jeux de données et permet une prévisualisation du résultat.','Stage de deuxième année à BPM-Conseil','2015-01-12','2015-02-13','Eclipse Kepler v4.3, Windows Seven, Serveur TomCat, Java/GWT, MySQL WorkBench, OpenStreetMap, Javascript OpenLayers','','','O','2015-03-19');
insert into port_situation values('581','76','2','4','1','2','Année 2 - Veille technologique et complément de formation','Mise en place d\\\'une veille technologique au cours de la deuxième année d\\\'étude.\r\nRecherche et mise à niveau sur des points clés comme le C++','','2014-09-01','2015-06-11','Recherche Google et aggrégat d\\\'informations sur Facebook et Feedly','','Je pense que la veille est le moyen de formation le plus efficace en information qui est un milieu en perpétuelle évolution','O','2015-02-26');
insert into port_situation values('589','75','2','4','1','2','PPE - Veille technologique','Description de la veille technologique','PPE ','2013-09-03','2015-02-26','Feedly, Appy Geek','','','O','2015-03-19');
insert into port_situation values('605','76','2','4','1','1','Année 2 - PPE C#','Développement en équipe de 4 étudiants du back-office commercial dans le contexte de GSB.\r\nJe me suis occupé de la partie de gestion des commandes et de la base de données','GSB','2014-12-15','2015-02-27','Visual Studio, git, SQL Server','','Mise en pratique des connaissances acquises en cours dans un projet qui pourrait presque être utilisé.','O','2015-04-27');
insert into port_situation values('607','75','2','4','1','1','PPE-CSharp','Projet Professionnel Encadré réalisé lors de la deuxième année de BTS sur le projet GSB C#.','BTS 2ème année','2015-03-24','2015-03-24','Windows 8, NetBeans, Team Foundation Serveur, MySQL','','','O','2015-03-26');
insert into port_situation values('608','75','2','4','1','1','PPE-PHP','Projet Professionnel Encadré réalisé lors de la deuxième année de BTS sur le projet GSB PHP.','BTS 2ème année','2015-03-24','2015-03-24','Windows 8, Notepad++, Uwamp, MySQL','','','O','2015-03-26');
insert into port_situation values('609','76','2','4','1','1','Année 2 - PPE PHP','Développement PHP de modules d\\\'un site web gsb existant. Je me suis occupé de la partie BDD, validation des fiches et suivi du paiement.','GSB','2015-02-02','2015-03-16','Notepadd++, UwAmp, git, google','','J\\\'ai trouvé le projet bien trop facile pour être intéressant','O','2015-04-27');
insert into port_situation values('1322','7','1','1','1','1','test','test','','2018-05-20','2018-05-20','','','','O','2018-05-20');
insert into port_situation values('1323','7','1','1','1','1','sqdae','azeazeaze','azezaeaze','2018-06-04','2018-06-04','aeazezae','azeaze','azeaze','O','2018-06-04');
insert into port_situation values('1324','7','2','1','1','1','sqdae','rreyrut','retyreyrt','2018-06-04','2018-06-04','trutykf','gjghjkhgs','ytytkukjkhjhhk','O','2018-06-04');
insert into port_situation values('1325','77','1','1','1','1','sqdae','lm','','2018-06-05','2018-06-05','','','','O','2018-06-05');
insert into port_situation values('1326','7','1','1','1','1','hthth','trgrt','thtrhrtfhrthj','2018-06-06','2018-06-06','','','','O','2018-06-06');
insert into port_situation values('1327','23','1','1','1','1','gogogo','gufhgouizjgiohdfrh','tdgj;ghkghjj:kk','2018-06-07','2018-06-07','','','','O','2018-06-07');
CREATE TABLE `port_source` (
  `code` smallint(6) NOT NULL,
  `libelle` char(20) NOT NULL,
  `codeTypesource` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
insert into port_source values('1','Stage 1','2');
insert into port_source values('2','Stage 2','3');
insert into port_source values('3','TP','1');
insert into port_source values('4','PPE','1');
CREATE TABLE `port_type` (
  `code` smallint(6) NOT NULL,
  `libelle` char(12) NOT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
insert into port_type values('1','Vécu');
insert into port_type values('2','Observé');
insert into port_type values('3','Simulé');
CREATE TABLE `port_typesource` (
  `code` smallint(6) NOT NULL,
  `libelle` varchar(70) NOT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
insert into port_typesource values('1','SITUATIONS VÉCUES EN FORMATION');
insert into port_typesource values('2','SITUATIONS VÉCUES EN STAGE DE PREMIÈRE ANNÉE DANS L’ORGANISATION');
insert into port_typesource values('3','SITUATIONS VÉCUES EN STAGE DE DEUXIÈME ANNÉE DANS L’ORGANISATION');
CREATE TABLE `port_typologie` (
  `code` smallint(6) NOT NULL,
  `lngutile` smallint(6) NOT NULL,
  `libelle` varchar(85) NOT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
insert into port_typologie values('1','56','Production d’une solution logicielle et d’infrastructure');
insert into port_typologie values('2','55','Prise en charge d’incidents et de demandes d’assistance');
insert into port_typologie values('3','49','Élaboration de documents relatifs à la production et à la fourniture de services');
insert into port_typologie values('4','53','Mise en place d’un dispositif de veille technologique');
